<?php
require_once '../includes/auth_admin.php';

// Lazy check tidak ada keterangan
cekDanInsertTidakAdaKeterangan($conn);

$today = getTodayDate();

$total_guru   = $conn->query("SELECT COUNT(*) as t FROM guru")->fetch_assoc()['t'];
$hadir        = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE tanggal='$today' AND status='hadir' AND jam_masuk IS NOT NULL")->fetch_assoc()['t'];
$terlambat    = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE tanggal='$today' AND status='terlambat'")->fetch_assoc()['t'];
$izin         = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE tanggal='$today' AND status='izin'")->fetch_assoc()['t'];
$sakit        = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE tanggal='$today' AND status='sakit'")->fetch_assoc()['t'];
$tak          = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE tanggal='$today' AND status='tidak_ada_keterangan'")->fetch_assoc()['t'];
$sudah_pulang = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE tanggal='$today' AND jam_pulang IS NOT NULL")->fetch_assoc()['t'];
$belum_absen  = max(0, $total_guru - $hadir - $terlambat - $izin - $sakit - $tak);

$semua_guru = $conn->query("
    SELECT g.nama, g.nip, a.status, a.jam_masuk, a.jam_pulang, a.keterangan
    FROM guru g
    LEFT JOIN absensi a ON g.id = a.guru_id AND a.tanggal = '$today'
    ORDER BY g.nama ASC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Sistem Absensi Guru</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
    <!-- MOBILE HEADER -->
    <div class="mobile-header">
        <button class="hamburger-btn" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>
        <div class="mh-brand">
            <div class="mh-icon">📊</div>
            <span>Dashboard Admin</span>
        </div>
        <div class="mh-actions">
            <a href="../logout.php" class="mh-logout-btn" onclick="return confirm('Yakin ingin keluar?')" title="Keluar">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>
    <div class="sidebar-overlay"></div>

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-brand">
                <div class="brand-icon">🛡️</div>
                <div class="brand-text"><h2>Admin Panel</h2><p>Sistem Absensi</p></div>
            </div>
        </div>
        <div class="sidebar-user">
            <div class="user-avatar" style="background:linear-gradient(135deg,#f59e0b,#d97706);">AD</div>
            <div class="user-info">
                <h4><?= htmlspecialchars($admin['nama']) ?></h4>
                <p>Administrator</p>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Dashboard</div>
                <a href="dashboard.php" class="nav-item active"><i class="fas fa-chart-line nav-icon"></i> Dashboard</a>
            </div>
            <div class="nav-section">
                <div class="nav-section-title">Manajemen</div>
                <a href="guru.php" class="nav-item"><i class="fas fa-chalkboard-teacher nav-icon"></i> Data Guru</a>
                <a href="absensi.php" class="nav-item"><i class="fas fa-clipboard-list nav-icon"></i> Data Absensi</a>
            </div>
        </nav>
        <div class="sidebar-footer">
            <a href="../logout.php" class="nav-item" onclick="return confirm('Yakin ingin keluar?')">
                <i class="fas fa-sign-out-alt nav-icon"></i> Keluar
            </a>
        </div>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left">
                <h1>Dashboard Admin</h1>
                <p>Ringkasan kehadiran hari ini</p>
            </div>
            <div class="topbar-date">
                <i class="fas fa-calendar-day"></i> <?= formatDate($today) ?>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card blue">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-value"><?= $total_guru ?></div>
                <div class="stat-label">Total Guru</div>
            </div>
            <div class="stat-card green">
                <div class="stat-icon"><i class="fas fa-user-check"></i></div>
                <div class="stat-value"><?= $hadir ?></div>
                <div class="stat-label">Hadir</div>
            </div>
            <div class="stat-card yellow">
                <div class="stat-icon"><i class="fas fa-clock"></i></div>
                <div class="stat-value"><?= $terlambat ?></div>
                <div class="stat-label">Terlambat</div>
            </div>
            <div class="stat-card" style="background:white;border:1px solid var(--gray-200);">
                <div class="stat-icon" style="background:var(--primary-light);color:var(--primary);"><i class="fas fa-file-alt"></i></div>
                <div class="stat-value"><?= $izin ?></div>
                <div class="stat-label">Izin</div>
            </div>
            <div class="stat-card red">
                <div class="stat-icon"><i class="fas fa-briefcase-medical"></i></div>
                <div class="stat-value"><?= $sakit ?></div>
                <div class="stat-label">Sakit</div>
            </div>
            <div class="stat-card" style="background:white;border:1px solid var(--gray-200);">
                <div class="stat-icon" style="background:#f1f5f9;color:#64748b;"><i class="fas fa-question-circle"></i></div>
                <div class="stat-value"><?= $tak ?></div>
                <div class="stat-label">Tidak Ada Ket.</div>
            </div>
        </div>

        <!-- Progress -->
        <?php
        $persen_hadir     = $total_guru > 0 ? round(($hadir/$total_guru)*100) : 0;
        $persen_terlambat = $total_guru > 0 ? round(($terlambat/$total_guru)*100) : 0;
        $persen_izin      = $total_guru > 0 ? round(($izin/$total_guru)*100) : 0;
        $persen_sakit     = $total_guru > 0 ? round(($sakit/$total_guru)*100) : 0;
        $persen_tak       = $total_guru > 0 ? round(($tak/$total_guru)*100) : 0;
        ?>
        <div class="card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-chart-bar"></i> Rekapitulasi Kehadiran Hari Ini</div>
            </div>
            <div class="card-body">
                <div style="display:flex;flex-direction:column;gap:12px;">
                    <?php foreach ([
                        ['✅ Hadir',               'var(--success)', $hadir,     $persen_hadir],
                        ['⚠️ Terlambat',           '#d97706',        $terlambat, $persen_terlambat],
                        ['📋 Izin',                'var(--primary)', $izin,      $persen_izin],
                        ['🏥 Sakit',               'var(--danger)',  $sakit,     $persen_sakit],
                        ['❓ Tidak Ada Keterangan','var(--gray-500)',$tak,       $persen_tak],
                    ] as [$label, $color, $val, $pct]): if ($total_guru === 0) continue; ?>
                    <div>
                        <div style="display:flex;justify-content:space-between;font-size:0.875rem;margin-bottom:5px;">
                            <span style="color:<?= $color ?>;font-weight:600;"><?= $label ?></span>
                            <span><?= $val ?> guru (<?= $pct ?>%)</span>
                        </div>
                        <div style="background:var(--gray-200);border-radius:99px;height:10px;">
                            <div style="background:<?= $color ?>;height:100%;width:<?= $pct ?>%;border-radius:99px;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- Tabel Status Semua Guru -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-list-check"></i> Status Semua Guru — <?= formatDate($today) ?></div>
                <a href="absensi.php" class="btn btn-outline btn-sm">Lihat Semua Data</a>
            </div>
            <div class="card-body" style="padding:0;">
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Guru</th>
                                <th>NIP</th>
                                <th>Status</th>
                                <th>Jam Masuk</th>
                                <th>Jam Pulang</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $no=1; while ($row=$semua_guru->fetch_assoc()):
                            $statusMap = [
                                'hadir'               => ['badge-success',   '✅ Hadir'],
                                'terlambat'           => ['badge-warning',   '⚠️ Terlambat'],
                                'tidak_ada_keterangan'=> ['badge-secondary', '❓ Tidak Ada Ket.'],
                                'izin'                => ['badge-primary',   '📋 Izin'],
                                'sakit'               => ['badge-danger',    '🏥 Sakit'],
                            ];
                            [$cls,$lbl] = $statusMap[$row['status'] ?? ''] ?? ['badge-secondary','Belum Absen'];
                        ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:10px;">
                                        <div class="user-avatar" style="width:32px;height:32px;font-size:0.75rem;flex-shrink:0;">
                                            <?= strtoupper(substr($row['nama'],0,2)) ?>
                                        </div>
                                        <strong><?= htmlspecialchars($row['nama']) ?></strong>
                                    </div>
                                </td>
                                <td><code><?= htmlspecialchars($row['nip']) ?></code></td>
                                <td><span class="badge <?= $cls ?>" style="font-size:.72rem;"><?= $lbl ?></span></td>
                                <td>
                                    <?php if ($row['jam_masuk']): ?>
                                        <span style="color:var(--success);font-weight:600;">
                                            <i class="fas fa-sign-in-alt"></i> <?= formatTime($row['jam_masuk']) ?>
                                        </span>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['jam_pulang']): ?>
                                        <span style="color:var(--danger);font-weight:600;">
                                            <i class="fas fa-sign-out-alt"></i> <?= formatTime($row['jam_pulang']) ?>
                                        </span>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td style="font-size:0.8125rem;color:var(--gray-600);max-width:150px;">
                                    <?= htmlspecialchars($row['keterangan'] ?: '—') ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="../js/mobile.js"></script>
</body>
</html>
