<?php
require_once '../includes/auth_admin.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: absensi.php');
    exit();
}

$aksi = sanitize($conn, $_POST['aksi'] ?? '');
$id   = (int)($_POST['id'] ?? 0);

// ============================================================
// HAPUS MASSAL (tidak butuh $id)
// ============================================================
if ($aksi === 'hapus_massal') {
    $tipe    = $_POST['hapus_tipe'] ?? '';
    $guru_id = (int)($_POST['hapus_guru_id'] ?? 0);
    $where   = []; $params = ''; $bindVals = [];

    if ($tipe === 'bulan') {
        $bulan = sanitize($conn, $_POST['hapus_bulan'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}$/', $bulan)) {
            $_SESSION['notif'] = ['type'=>'error','msg'=>'Format bulan tidak valid.'];
            header('Location: absensi.php'); exit();
        }
        $where[] = "DATE_FORMAT(tanggal,'%Y-%m') = ?";
        $params .= 's'; $bindVals[] = $bulan;
    } elseif ($tipe === 'tanggal') {
        $tanggal = sanitize($conn, $_POST['hapus_tanggal'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
            $_SESSION['notif'] = ['type'=>'error','msg'=>'Format tanggal tidak valid.'];
            header('Location: absensi.php'); exit();
        }
        $where[] = "tanggal = ?";
        $params .= 's'; $bindVals[] = $tanggal;
    } else {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Tipe hapus tidak valid.'];
        header('Location: absensi.php'); exit();
    }
    if ($guru_id > 0) { $where[] = "guru_id = ?"; $params .= 'i'; $bindVals[] = $guru_id; }

    $whereSQL = 'WHERE ' . implode(' AND ', $where);

    // Hapus file bukti dari disk dulu
    $stmtFiles = $conn->prepare("SELECT bukti_file FROM absensi $whereSQL");
    $stmtFiles->bind_param($params, ...$bindVals);
    $stmtFiles->execute();
    $resFiles = $stmtFiles->get_result();
    while ($f = $resFiles->fetch_assoc()) {
        if (!empty($f['bukti_file'])) {
            $fp = '../uploads/bukti/' . $f['bukti_file'];
            if (file_exists($fp)) unlink($fp);
        }
    }
    $stmtFiles->close();

    $stmtDel = $conn->prepare("DELETE FROM absensi $whereSQL");
    $stmtDel->bind_param($params, ...$bindVals);
    if ($stmtDel->execute()) {
        $jml = $stmtDel->affected_rows;
        $_SESSION['notif'] = ['type'=>'success','msg'=>"$jml data absensi berhasil dihapus."];
    } else {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal menghapus data.'];
    }
    $stmtDel->close();
    header('Location: absensi.php'); exit();
}

// Aksi lain butuh $id valid
if (!$id) {
    $_SESSION['notif'] = ['type'=>'error','msg'=>'ID tidak valid.'];
    header('Location: absensi.php'); exit();
}

// ============================================================
// AKSI: UPLOAD BUKTI (tombol bukti terpisah)
// ============================================================
if ($aksi === 'upload_bukti') {
    if (empty($_FILES['bukti_file']['tmp_name'])) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Tidak ada file yang dipilih.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }

    $upload_dir = '../uploads/bukti/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $file    = $_FILES['bukti_file'];
    $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','pdf'];

    if (!in_array($ext, $allowed)) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Format tidak diizinkan. Gunakan JPG, PNG, atau PDF.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    if (!in_array($mime, ['image/jpeg','image/png','application/pdf'])) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Tipe file tidak valid.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }

    if ($file['size'] > 5 * 1024 * 1024) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'File melebihi batas 5MB.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }

    // Hapus file lama jika ada
    $existing = $conn->query("SELECT bukti_file FROM absensi WHERE id = $id")->fetch_assoc();
    if (!empty($existing['bukti_file'])) {
        $old = $upload_dir . $existing['bukti_file'];
        if (file_exists($old)) unlink($old);
    }

    $new_name = 'bukti_' . $id . '_' . time() . '.' . $ext;
    if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
        $safe = sanitize($conn, $new_name);
        $stmt = $conn->prepare("UPDATE absensi SET bukti_file = ? WHERE id = ?");
        $stmt->bind_param('si', $safe, $id);
        $stmt->execute() ?
            $_SESSION['notif'] = ['type'=>'success','msg'=>'Bukti berhasil disimpan.'] :
            $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal menyimpan path file.'];
        $stmt->close();
    } else {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal memindahkan file ke server.'];
    }

    $referer  = $_SERVER['HTTP_REFERER'] ?? 'absensi.php';
    $parsed   = parse_url($referer);
    $safe_ref = ($parsed['path'] ?? 'absensi.php');
    if (!empty($parsed['query'])) $safe_ref .= '?' . $parsed['query'];
    header('Location: ' . $safe_ref); exit();
}

// ============================================================
// AKSI: HAPUS BUKTI SAJA (tidak hapus record absensi)
// ============================================================
if ($aksi === 'hapus_bukti') {
    $existing = $conn->query("SELECT bukti_file FROM absensi WHERE id = $id")->fetch_assoc();
    if (!empty($existing['bukti_file'])) {
        $fp = '../uploads/bukti/' . $existing['bukti_file'];
        if (file_exists($fp)) unlink($fp);
    }
    $stmt = $conn->prepare("UPDATE absensi SET bukti_file = NULL WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute() ?
        $_SESSION['notif'] = ['type'=>'success','msg'=>'Bukti berhasil dihapus.'] :
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal menghapus bukti.'];
    $stmt->close();

    $referer  = $_SERVER['HTTP_REFERER'] ?? 'absensi.php';
    $parsed   = parse_url($referer);
    $safe_ref = ($parsed['path'] ?? 'absensi.php');
    if (!empty($parsed['query'])) $safe_ref .= '?' . $parsed['query'];
    header('Location: ' . $safe_ref); exit();
}

// ============================================================
// AKSI: EDIT STATUS (Admin)
// Status yang boleh: hadir, terlambat, tidak_ada_keterangan, izin, sakit
// Jika izin/sakit → bukti wajib (upload atau sudah ada sebelumnya)
// ============================================================
if ($aksi === 'edit_status') {
    $allowed_status = ['hadir', 'terlambat', 'tidak_ada_keterangan', 'izin', 'sakit'];
    $status     = sanitize($conn, $_POST['status'] ?? '');
    $keterangan = sanitize($conn, $_POST['keterangan'] ?? '');
    $tanggal    = sanitize($conn, $_POST['tanggal'] ?? '');
    $guru_id    = (int)($_POST['guru_id'] ?? 0);
    $jam_masuk  = sanitize($conn, $_POST['jam_masuk'] ?? '');
    $jam_pulang = sanitize($conn, $_POST['jam_pulang'] ?? '');

    if (!in_array($status, $allowed_status)) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Status tidak valid.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Format tanggal tidak valid.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }
    if ($guru_id <= 0) {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Guru tidak valid.'];
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
    }

    $jam_masuk_val  = !empty($jam_masuk)  ? $jam_masuk  : null;
    $jam_pulang_val = !empty($jam_pulang) ? $jam_pulang : null;

    // Ambil data existing untuk cek bukti lama
    $existing = $conn->query("SELECT bukti_file FROM absensi WHERE id = $id")->fetch_assoc();
    $buktiSqlSet = '';

    // Jika ada file upload baru
    if (!empty($_FILES['bukti_file']['tmp_name'])) {
        $upload_dir = '../uploads/bukti/';
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

        $file     = $_FILES['bukti_file'];
        $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed  = ['jpg','jpeg','png','pdf'];
        $max_size = 5 * 1024 * 1024;

        if (!in_array($ext, $allowed)) {
            $_SESSION['notif'] = ['type'=>'error','msg'=>'Format file tidak diizinkan. Gunakan JPG, PNG, atau PDF.'];
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime  = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, ['image/jpeg','image/png','application/pdf'])) {
            $_SESSION['notif'] = ['type'=>'error','msg'=>'Tipe file tidak valid.'];
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
        }

        if ($file['size'] > $max_size) {
            $_SESSION['notif'] = ['type'=>'error','msg'=>'File melebihi batas 5MB.'];
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
        }

        // Hapus bukti lama
        if (!empty($existing['bukti_file'])) {
            $old = $upload_dir . $existing['bukti_file'];
            if (file_exists($old)) unlink($old);
        }

        $new_name = 'bukti_' . $id . '_' . time() . '.' . $ext;
        if (move_uploaded_file($file['tmp_name'], $upload_dir . $new_name)) {
            $safe = sanitize($conn, $new_name);
            $buktiSqlSet = ", bukti_file = '$safe'";
        } else {
            $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal upload file bukti.'];
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
        }
    }

    // Validasi: izin/sakit wajib punya bukti (baru atau sudah ada)
    if (in_array($status, ['izin','sakit'])) {
        $sudahAdaBukti = !empty($existing['bukti_file']) || !empty($_FILES['bukti_file']['tmp_name']);
        if (!$sudahAdaBukti) {
            $_SESSION['notif'] = ['type'=>'error','msg'=>"Status '$status' wajib disertai file bukti (surat izin/dokter). Harap upload terlebih dahulu."];
            header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? 'absensi.php')); exit();
        }
    }

    $stmt = $conn->prepare("UPDATE absensi SET status=?, keterangan=?, tanggal=?, guru_id=?, jam_masuk=?, jam_pulang=? $buktiSqlSet WHERE id=?");
    $stmt->bind_param('sssissi', $status, $keterangan, $tanggal, $guru_id, $jam_masuk_val, $jam_pulang_val, $id);
    if ($stmt->execute()) {
        $_SESSION['notif'] = ['type'=>'success','msg'=>'Status absensi berhasil diperbarui.'];
    } else {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal memperbarui status.'];
    }
    $stmt->close();

// ============================================================
// AKSI: HAPUS SATU DATA
// ============================================================
} elseif ($aksi === 'hapus') {
    $existing = $conn->query("SELECT bukti_file FROM absensi WHERE id = $id")->fetch_assoc();
    if (!empty($existing['bukti_file'])) {
        $fp = '../uploads/bukti/' . $existing['bukti_file'];
        if (file_exists($fp)) unlink($fp);
    }
    $stmt = $conn->prepare("DELETE FROM absensi WHERE id = ?");
    $stmt->bind_param('i', $id);
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $_SESSION['notif'] = ['type'=>'success','msg'=>'Data absensi berhasil dihapus.'];
    } else {
        $_SESSION['notif'] = ['type'=>'error','msg'=>'Gagal menghapus data.'];
    }
    $stmt->close();

} else {
    $_SESSION['notif'] = ['type'=>'error','msg'=>'Aksi tidak dikenal.'];
}

// Redirect aman
$referer  = $_SERVER['HTTP_REFERER'] ?? 'absensi.php';
$parsed   = parse_url($referer);
$safe_ref = ($parsed['path'] ?? 'absensi.php');
if (!empty($parsed['query'])) $safe_ref .= '?' . $parsed['query'];
header('Location: ' . $safe_ref);
exit();
