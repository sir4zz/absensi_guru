<?php
require_once '../includes/auth_admin.php';

cekDanInsertTidakAdaKeterangan($conn);

$filter_tanggal = sanitize($conn, $_GET['tanggal'] ?? '');
$filter_guru    = (int)($_GET['guru_id'] ?? 0);
$filter_bulan   = sanitize($conn, $_GET['bulan'] ?? date('Y-m'));
$filter_status  = sanitize($conn, $_GET['status'] ?? '');

$nmBulan  = ['','Januari','Februari','Maret','April','Mei','Juni',
             'Juli','Agustus','September','Oktober','November','Desember'];
$_bParts  = explode('-', $filter_bulan);
$tahunInt = (int)($_bParts[0] ?? date('Y'));
$bulanInt = (int)($_bParts[1] ?? date('n'));

$pending_klarifikasi = 0; // Klarifikasi dihapus dari flow ini

$where = [];
if ($filter_tanggal) {
    $where[] = "a.tanggal = '$filter_tanggal'";
} else {
    $where[] = "DATE_FORMAT(a.tanggal,'%Y-%m') = '$filter_bulan'";
}
if ($filter_guru)   $where[] = "a.guru_id = $filter_guru";
if ($filter_status) $where[] = "a.status = '$filter_status'";

$whereClause = count($where) ? 'WHERE ' . implode(' AND ', $where) : '';

$data = $conn->query("
    SELECT a.*, g.nama, g.nip
    FROM absensi a JOIN guru g ON a.guru_id = g.id
    $whereClause
    ORDER BY a.tanggal DESC, g.nama ASC
");
$guruList = $conn->query("SELECT id, nama FROM guru ORDER BY nama ASC");

$rows = [];
$cHadir = $cTerlambat = $cTAK = $cIzin = $cSakit = 0;
while ($row = $data->fetch_assoc()) {
    $rows[] = $row;
    if ($row['status']==='hadir')               $cHadir++;
    if ($row['status']==='terlambat')           $cTerlambat++;
    if ($row['status']==='tidak_ada_keterangan')$cTAK++;
    if ($row['status']==='izin')                $cIzin++;
    if ($row['status']==='sakit')               $cSakit++;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Absensi - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .selfie-thumb { width:44px;height:44px;border-radius:8px;object-fit:cover;cursor:pointer;border:2px solid var(--gray-200);transition:transform .15s,border-color .15s; }
        .selfie-thumb:hover { transform:scale(1.12);border-color:var(--primary); }
        .lightbox { display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;align-items:center;justify-content:center;flex-direction:column;gap:14px; }
        .lightbox.active { display:flex; }
        .lightbox img { max-width:90vw;max-height:80vh;border-radius:14px;box-shadow:0 8px 40px rgba(0,0,0,.6); }
        .lightbox-close { position:absolute;top:18px;right:22px;color:white;font-size:1.8rem;cursor:pointer; }

        /* MODAL */
        .modal-overlay { display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:8000;align-items:center;justify-content:center; }
        .modal-overlay.active { display:flex; }
        .modal-box { background:white;border-radius:16px;padding:28px 28px 24px;width:100%;max-width:480px;box-shadow:0 20px 60px rgba(0,0,0,.25);animation:modalIn .18s ease; }
        @keyframes modalIn { from{transform:translateY(-18px);opacity:0} to{transform:translateY(0);opacity:1} }
        .modal-title { font-size:1.05rem;font-weight:700;color:var(--gray-800);margin-bottom:18px;display:flex;align-items:center;gap:8px; }
        .modal-actions { display:flex;gap:10px;justify-content:flex-end;margin-top:20px; }

        /* NOTIFIKASI */
        .notif-bar { padding:12px 18px;border-radius:10px;font-weight:600;font-size:.875rem;display:flex;align-items:center;gap:10px;margin-bottom:16px;animation:notifIn .25s ease; }
        @keyframes notifIn { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
        .notif-success { background:#f0fdf4;color:#15803d;border:1px solid #bbf7d0; }
        .notif-error   { background:#fff1f2;color:#be123c;border:1px solid #fecdd3; }

        /* TOMBOL IKON */
        .btn-icon { display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;border-radius:7px;font-size:.82rem;font-weight:600;border:none;cursor:pointer;transition:filter .15s,transform .1s; }
        .btn-icon:hover { filter:brightness(.88);transform:translateY(-1px); }
        .btn-icon:active { transform:translateY(0); }
        .btn-icon-wrap { position:relative;display:inline-flex; }
        .btn-icon-wrap::after { content:attr(data-tip);position:absolute;bottom:calc(100% + 6px);left:50%;transform:translateX(-50%);background:rgba(30,30,30,.88);color:#fff;font-size:.72rem;padding:3px 8px;border-radius:5px;white-space:nowrap;pointer-events:none;z-index:10;opacity:0;transition:opacity .15s; }
        .btn-icon-wrap:hover::after { opacity:1; }
        .btn-edit-status  { background:#e0f2fe;color:#0369a1; }
        .btn-hapus        { background:#fff1f2;color:#be123c; }

        /* Upload area */
        .upload-area { border:2px dashed var(--gray-300);border-radius:10px;padding:20px 16px;text-align:center;cursor:pointer;background:white;transition:all .2s; }
        .upload-area:hover { border-color:var(--primary);background:var(--primary-light); }
        .upload-area.has-file { border-color:var(--success);background:#f0fdf4; }
        .bukti-preview-img { max-width:100%;max-height:180px;border-radius:8px;border:2px solid var(--gray-200);object-fit:contain; }

        /* Bukti wajib badge */
        .bukti-wajib { display:inline-flex;align-items:center;gap:4px;font-size:.72rem;background:#fef3c7;color:#92400e;border-radius:5px;padding:2px 7px;font-weight:700; }
        .btn-bukti { background:#f0fdf4;color:#15803d; }

        /* Hapus massal */
        .modal-box-wide { max-width:520px; }

        /* Preview bukti di modal */
        .bukti-current-box {
            display:flex; align-items:center; gap:12px;
            background:#f0fdf4; border:1.5px solid #bbf7d0;
            border-radius:10px; padding:12px 14px; margin-bottom:14px;
        }
        .bukti-current-box img { width:56px;height:56px;object-fit:cover;border-radius:8px;border:2px solid #bbf7d0;cursor:pointer; }
        .bukti-current-box .bukti-info { flex:1; }
        .bukti-current-box .bukti-info small { font-size:.72rem;color:#15803d; }
        .bukti-current-box .bukti-info strong { display:block;font-size:.83rem;color:#065f46;word-break:break-all; }
        .btn-hapus-bukti { background:none;border:none;cursor:pointer;color:#be123c;font-size:.78rem;font-weight:700;display:flex;align-items:center;gap:4px;padding:4px 8px;border-radius:6px;transition:background .15s; }
        .btn-hapus-bukti:hover { background:#fff1f2; }
    </style>
</head>
<body>
<div class="app-layout">
    <!-- MOBILE HEADER -->
    <div class="mobile-header">
        <button class="hamburger-btn"><span></span><span></span><span></span></button>
        <div class="mh-brand"><div class="mh-icon">✅</div><span>Data Absensi Guru</span></div>
        <div class="mh-actions">
            <a href="../logout.php" class="mh-logout-btn" onclick="return confirm('Yakin keluar?')"><i class="fas fa-sign-out-alt"></i></a>
        </div>
    </div>
    <div class="sidebar-overlay"></div>

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-brand">
                <div class="brand-icon">🛡️</div>
                <div class="brand-text"><h2>Admin Panel</h2><p>Sistem Absensi</p></div>
            </div>
        </div>
        <div class="sidebar-user">
            <div class="user-avatar" style="background:linear-gradient(135deg,#f59e0b,#d97706);">AD</div>
            <div class="user-info"><h4><?= htmlspecialchars($admin['nama']) ?></h4><p>Administrator</p></div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Dashboard</div>
                <a href="dashboard.php" class="nav-item"><i class="fas fa-chart-line nav-icon"></i> Dashboard</a>
            </div>
            <div class="nav-section">
                <div class="nav-section-title">Manajemen</div>
                <a href="guru.php" class="nav-item"><i class="fas fa-chalkboard-teacher nav-icon"></i> Data Guru</a>
                <a href="absensi.php" class="nav-item active"><i class="fas fa-clipboard-list nav-icon"></i> Data Absensi</a>
            </div>
        </nav>
        <div class="sidebar-footer">
            <a href="../logout.php" class="nav-item" onclick="return confirm('Yakin keluar?')">
                <i class="fas fa-sign-out-alt nav-icon"></i> Keluar
            </a>
        </div>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left"><h1>Data Absensi Guru</h1><p>Rekap lengkap kehadiran semua guru</p></div>
        </div>

        <!-- Notifikasi -->
        <?php if (!empty($_SESSION['notif'])): ?>
        <?php $notif = $_SESSION['notif']; unset($_SESSION['notif']); ?>
        <div class="notif-bar notif-<?= $notif['type']==='success'?'success':'error' ?>" id="notifBar">
            <i class="fas fa-<?= $notif['type']==='success'?'check-circle':'exclamation-circle' ?>"></i>
            <?= htmlspecialchars($notif['msg']) ?>
            <button onclick="this.parentElement.remove()" style="margin-left:auto;background:none;border:none;cursor:pointer;font-size:1rem;color:inherit;">✕</button>
        </div>
        <script>setTimeout(()=>{ var n=document.getElementById('notifBar'); if(n) n.remove(); }, 4000);</script>
        <?php endif; ?>

        <!-- Filter -->
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-filter"></i> Filter Data</div></div>
            <div class="card-body">
                <form method="GET" class="filter-bar" style="flex-wrap:wrap;">
                    <div class="form-group" style="margin-bottom:0;min-width:150px;">
                        <label style="font-size:.8125rem;margin-bottom:4px;">Bulan</label>
                        <input type="month" name="bulan" class="form-control" value="<?= htmlspecialchars($filter_bulan) ?>">
                    </div>
                    <div class="form-group" style="margin-bottom:0;min-width:160px;">
                        <label style="font-size:.8125rem;margin-bottom:4px;">Tanggal Spesifik</label>
                        <input type="date" name="tanggal" class="form-control" value="<?= htmlspecialchars($filter_tanggal) ?>">
                    </div>
                    <div class="form-group" style="margin-bottom:0;min-width:180px;">
                        <label style="font-size:.8125rem;margin-bottom:4px;">Guru</label>
                        <select name="guru_id" class="form-control">
                            <option value="0">Semua Guru</option>
                            <?php $guruList->data_seek(0); while ($g=$guruList->fetch_assoc()): ?>
                            <option value="<?= $g['id'] ?>" <?= $filter_guru==$g['id']?'selected':'' ?>><?= htmlspecialchars($g['nama']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group" style="margin-bottom:0;min-width:200px;">
                        <label style="font-size:.8125rem;margin-bottom:4px;">Status</label>
                        <select name="status" class="form-control">
                            <option value="">Semua Status</option>
                            <option value="hadir"               <?= $filter_status==='hadir'?'selected':''               ?>>✅ Hadir</option>
                            <option value="terlambat"           <?= $filter_status==='terlambat'?'selected':''           ?>>⚠️ Terlambat</option>
                            <option value="tidak_ada_keterangan"<?= $filter_status==='tidak_ada_keterangan'?'selected':''?>>❓ Tidak Ada Keterangan</option>
                            <option value="izin"                <?= $filter_status==='izin'?'selected':''                ?>>📋 Izin</option>
                            <option value="sakit"               <?= $filter_status==='sakit'?'selected':''               ?>>🏥 Sakit</option>
                        </select>
                    </div>
                    <div style="display:flex;gap:8px;align-self:flex-end;">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tampilkan</button>
                        <a href="absensi.php" class="btn btn-outline">Reset</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Export Excel -->
        <div class="card" style="margin-bottom:0;border:2px solid #16a34a22;">
            <div class="card-header" style="background:linear-gradient(135deg,#f0fdf4,#dcfce7);border-bottom:1px solid #bbf7d0;">
                <div class="card-title" style="color:#15803d;"><i class="fas fa-file-excel" style="color:#16a34a;font-size:1.1rem;"></i> Export Laporan ke Excel</div>
            </div>
            <div class="card-body">
                <form method="GET" action="export_excel.php" target="_blank"
                      style="display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 16px;">
                    <div class="form-group" style="margin-bottom:0;min-width:160px;">
                        <label style="font-size:.8rem;font-weight:600;color:#374151;margin-bottom:4px;display:block;"><i class="fas fa-calendar-alt" style="color:#16a34a;"></i> Pilih Bulan</label>
                        <input type="month" name="bulan" value="<?= htmlspecialchars($filter_bulan) ?>" class="form-control">
                    </div>
                    <button type="submit" class="btn" style="background:linear-gradient(135deg,#16a34a,#15803d);color:white;padding:10px 20px;font-weight:700;border-radius:10px;">
                        <i class="fas fa-download"></i> Download Excel
                    </button>
                </form>
            </div>
        </div>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat-card blue"><div class="stat-icon"><i class="fas fa-list"></i></div><div class="stat-value"><?= count($rows) ?></div><div class="stat-label">Total Record</div></div>
            <div class="stat-card green"><div class="stat-icon"><i class="fas fa-user-check"></i></div><div class="stat-value"><?= $cHadir ?></div><div class="stat-label">Hadir</div></div>
            <div class="stat-card yellow"><div class="stat-icon"><i class="fas fa-clock"></i></div><div class="stat-value"><?= $cTerlambat ?></div><div class="stat-label">Terlambat</div></div>
            <div class="stat-card" style="background:white;border:1px solid var(--gray-200);"><div class="stat-icon" style="background:#f1f5f9;color:#64748b;"><i class="fas fa-question-circle"></i></div><div class="stat-value"><?= $cTAK ?></div><div class="stat-label">Tidak Ada Ket.</div></div>
            <div class="stat-card" style="background:white;border:1px solid var(--gray-200);"><div class="stat-icon" style="background:var(--primary-light);color:var(--primary);"><i class="fas fa-file-alt"></i></div><div class="stat-value"><?= $cIzin ?></div><div class="stat-label">Izin</div></div>
            <div class="stat-card red"><div class="stat-icon"><i class="fas fa-briefcase-medical"></i></div><div class="stat-value"><?= $cSakit ?></div><div class="stat-label">Sakit</div></div>
        </div>

        <!-- Tabel -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-table"></i> Rekap Absensi</div>
                <div style="display:flex;align-items:center;gap:10px;">
                    <span class="badge badge-primary"><?= count($rows) ?> data</span>
                    <button class="btn btn-danger btn-sm" onclick="bukaModalHapusMassal()" style="font-size:.8rem;">
                        <i class="fas fa-trash-alt"></i> Hapus Massal
                    </button>
                </div>
            </div>
            <div class="card-body" style="padding:0;">
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Nama Guru</th>
                                <th>Status</th>
                                <th>Jam Masuk</th>
                                <th>Jam Pulang</th>
                                <th>Foto</th>
                                <th>Bukti Izin/Sakit</th>
                                <th>Keterangan</th>
                                <th style="text-align:center;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (count($rows)>0): $no=1; foreach ($rows as $row): ?>
                            <?php
                            $rowBg = '';
                            if ($row['status']==='tidak_ada_keterangan') $rowBg='background:#fafafa;';
                            if ($row['status']==='terlambat') $rowBg='background:#fffbeb;';
                            ?>
                            <tr style="<?= $rowBg ?>">
                                <td><?= $no++ ?></td>
                                <td><strong><?= formatDate($row['tanggal']) ?></strong></td>
                                <td>
                                    <div style="display:flex;align-items:center;gap:8px;">
                                        <div class="user-avatar" style="width:28px;height:28px;font-size:.7rem;flex-shrink:0;"><?= strtoupper(substr($row['nama'],0,2)) ?></div>
                                        <?= htmlspecialchars($row['nama']) ?>
                                    </div>
                                </td>
                                <td>
                                    <?php
                                    $statusMap = [
                                        'hadir'               => ['badge-success', '✅ Hadir'],
                                        'terlambat'           => ['badge-warning', '⚠️ Terlambat'],
                                        'tidak_ada_keterangan'=> ['badge-secondary', '❓ Tidak Ada Ket.'],
                                        'izin'                => ['badge-primary', '📋 Izin'],
                                        'sakit'               => ['badge-danger', '🏥 Sakit'],
                                    ];
                                    [$cls,$lbl] = $statusMap[$row['status']] ?? ['badge-secondary','—'];
                                    echo "<span class='badge $cls' style='font-size:.72rem;'>$lbl</span>";
                                    ?>
                                </td>
                                <td>
                                    <?php if ($row['jam_masuk']): ?>
                                        <span style="color:var(--success);font-weight:600;"><i class="fas fa-sign-in-alt"></i> <?= formatTime($row['jam_masuk']) ?></span>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['jam_pulang']): ?>
                                        <span style="color:var(--danger);font-weight:600;"><i class="fas fa-sign-out-alt"></i> <?= formatTime($row['jam_pulang']) ?></span>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $fotos = [];
                                    if (!empty($row['foto_masuk']))  $fotos[] = ['../uploads/selfie/'.$row['foto_masuk'],  'Masuk',  $row['jam_masuk']??''];
                                    if (!empty($row['foto_pulang'])) $fotos[] = ['../uploads/selfie/'.$row['foto_pulang'], 'Pulang', $row['jam_pulang']??''];
                                    if ($fotos): ?>
                                    <div style="display:flex;gap:4px;">
                                        <?php foreach ($fotos as [$src,$tipe,$jam]): ?>
                                        <img src="<?= htmlspecialchars($src) ?>" class="selfie-thumb"
                                             onclick="bukaLightbox('<?= htmlspecialchars($src) ?>','<?= htmlspecialchars($row['nama']) ?>','<?= formatTime($jam) ?>','<?= $tipe ?>')"
                                             title="<?= $tipe ?>">
                                        <?php endforeach; ?>
                                    </div>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['bukti_file'])): ?>
                                        <?php $ext = strtolower(pathinfo($row['bukti_file'], PATHINFO_EXTENSION)); ?>
                                        <?php if (in_array($ext,['jpg','jpeg','png'])): ?>
                                            <img src="../uploads/bukti/<?= htmlspecialchars($row['bukti_file']) ?>"
                                                 style="width:44px;height:44px;border-radius:6px;object-fit:cover;cursor:pointer;border:2px solid var(--gray-200);"
                                                 onclick="bukaLightbox('../uploads/bukti/<?= htmlspecialchars($row['bukti_file']) ?>','<?= htmlspecialchars(addslashes($row['nama'])) ?>','','Bukti')">
                                        <?php else: ?>
                                            <a href="../uploads/bukti/<?= htmlspecialchars($row['bukti_file']) ?>" target="_blank" class="btn btn-outline btn-sm" style="font-size:.72rem;padding:3px 8px;">
                                                <i class="fas fa-file-pdf" style="color:#dc2626;"></i> PDF
                                            </a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if (in_array($row['status'],['izin','sakit'])): ?>
                                            <span class="bukti-wajib"><i class="fas fa-exclamation-triangle"></i> Belum ada</span>
                                        <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <td style="max-width:160px;">
                                    <span style="font-size:.8rem;color:var(--gray-600);"><?= htmlspecialchars($row['keterangan'] ?? '—') ?></span>
                                </td>
                                <td style="text-align:center;white-space:nowrap;">
                                    <div style="display:flex;gap:5px;justify-content:center;align-items:center;">
                                        <span class="btn-icon-wrap" data-tip="Edit Absensi">
                                            <button class="btn-icon btn-edit-status"
                                                onclick="bukaModalEditStatus(
                                                    <?= $row['id'] ?>,
                                                    '<?= htmlspecialchars(addslashes($row['nama'])) ?>',
                                                    '<?= $row['status'] ?>',
                                                    '<?= htmlspecialchars(addslashes($row['keterangan'] ?? '')) ?>',
                                                    '<?= htmlspecialchars($row['bukti_file'] ?? '') ?>',
                                                    '<?= $row['tanggal'] ?>',
                                                    <?= $row['guru_id'] ?>,
                                                    '<?= substr($row['jam_masuk'] ?? '', 0, 5) ?>',
                                                    '<?= substr($row['jam_pulang'] ?? '', 0, 5) ?>'
                                                )">
                                                <i class="fas fa-pen"></i>
                                            </button>
                                        </span>
                                        <span class="btn-icon-wrap" data-tip="<?= !empty($row['bukti_file']) ? 'Lihat / Ganti Bukti' : 'Upload Bukti' ?>">
                                            <button class="btn-icon btn-bukti"
                                                onclick="bukaModalBukti(
                                                    <?= $row['id'] ?>,
                                                    '<?= htmlspecialchars(addslashes($row['nama'])) ?>',
                                                    '<?= $row['status'] ?>',
                                                    '<?= htmlspecialchars($row['bukti_file'] ?? '') ?>'
                                                )" style="<?= !empty($row['bukti_file']) ? 'border:2px solid #15803d;' : '' ?>">
                                                <i class="fas fa-<?= !empty($row['bukti_file']) ? 'paperclip' : 'upload' ?>"></i>
                                            </button>
                                        </span>
                                        <span class="btn-icon-wrap" data-tip="Hapus">
                                            <button class="btn-icon btn-hapus"
                                                onclick="konfirmasiHapus(<?= $row['id'] ?>, '<?= htmlspecialchars(addslashes($row['nama'])) ?>')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </span>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr><td colspan="10" class="table-empty">
                                <div class="empty-icon">📋</div>
                                <div>Tidak ada data untuk filter yang dipilih</div>
                            </td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Lightbox -->
<div class="lightbox" id="lightbox" onclick="tutupLightbox()">
    <span class="lightbox-close">✕</span>
    <img id="lightbox-img" src="" alt="">
</div>

<!-- =====================================================================
     MODAL: EDIT STATUS ABSENSI (Admin)
     Status: hadir, terlambat, tidak_ada_keterangan, izin, sakit
     Izin/Sakit → upload bukti WAJIB
===================================================================== -->
<div class="modal-overlay" id="modalEditStatus">
    <div class="modal-box modal-box-wide">
        <div class="modal-title">
            <i class="fas fa-pen" style="color:var(--primary);"></i>
            Edit Absensi —
            <span id="modalEditNama" style="color:var(--gray-500);font-weight:500;font-size:.9rem;"></span>
        </div>
        <form method="POST" action="proses_absensi.php" enctype="multipart/form-data">
            <input type="hidden" name="aksi" value="edit_status">
            <input type="hidden" name="id" id="editStatusId">

            <div style="display:flex;gap:12px;">
                <div class="form-group" style="flex:1;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">Tanggal</label>
                    <input type="date" name="tanggal" id="editTanggal" class="form-control" required>
                </div>
                <div class="form-group" style="flex:1;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">Nama Guru</label>
                    <select name="guru_id" id="editGuruId" class="form-control" required>
                        <?php $guruList->data_seek(0); while ($g = $guruList->fetch_assoc()): ?>
                        <option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['nama']) ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">Status Kehadiran</label>
                <select name="status" id="editStatusVal" class="form-control" required onchange="onStatusChange()">
                    <option value="hadir">               ✅ Hadir</option>
                    <option value="terlambat">           ⚠️ Terlambat</option>
                    <option value="tidak_ada_keterangan">❓ Tidak Ada Keterangan</option>
                    <option value="izin">                📋 Izin</option>
                    <option value="sakit">               🏥 Sakit</option>
                </select>
            </div>

            <div style="display:flex;gap:12px;">
                <div class="form-group" style="flex:1;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">Jam Masuk <span style="font-weight:400;color:var(--gray-400);">(opsional)</span></label>
                    <input type="time" name="jam_masuk" id="editJamMasuk" class="form-control">
                </div>
                <div class="form-group" style="flex:1;">
                    <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">Jam Pulang <span style="font-weight:400;color:var(--gray-400);">(opsional)</span></label>
                    <input type="time" name="jam_pulang" id="editJamPulang" class="form-control">
                </div>
            </div>

            <!-- Bukti — tampil & wajib jika izin/sakit -->
            <div class="form-group" id="buktiSection" style="display:none;">
                <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">
                    Bukti (Surat Izin / Surat Dokter) <span style="color:var(--danger);">*</span>
                    <span style="font-size:.75rem;font-weight:400;color:var(--gray-400);">JPG, PNG, PDF — maks. 5MB</span>
                </label>

                <!-- Bukti yang sudah ada — preview dengan gambar & link -->
                <div id="buktiAda" style="display:none;margin-bottom:12px;">
                    <div class="bukti-current-box" style="background:#fffbeb;border-color:#fde68a;">
                        <div id="editBuktiCurrentThumb"></div>
                        <div class="bukti-info">
                            <small style="color:#92400e;">Bukti tersimpan — upload baru untuk mengganti</small>
                            <strong id="editBuktiCurrentName" style="color:#78350f;"></strong>
                            <div style="margin-top:4px;">
                                <a id="editBuktiCurrentLink" href="#" target="_blank"
                                   class="btn btn-outline btn-sm" style="font-size:.72rem;padding:2px 8px;">
                                    <i class="fas fa-eye"></i> Lihat
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="upload-area" id="editUploadArea" onclick="document.getElementById('editBuktiFile').click()">
                    <div style="font-size:1.5rem;">📎</div>
                    <div style="font-weight:600;font-size:.88rem;color:var(--gray-700);">Klik untuk pilih file</div>
                    <div style="font-size:.75rem;color:var(--gray-400);margin-top:3px;">JPG · PNG · PDF</div>
                </div>
                <input type="file" name="bukti_file" id="editBuktiFile" accept=".jpg,.jpeg,.png,.pdf" style="display:none;"
                       onchange="previewEditBukti(this)">
                <div id="editBuktiPreview" style="display:none;margin-top:8px;"></div>
            </div>

            <div class="form-group" style="margin-top:14px;">
                <label style="font-size:.85rem;font-weight:600;color:var(--gray-700);margin-bottom:6px;display:block;">Keterangan <span style="font-weight:400;color:var(--gray-400);">(opsional)</span></label>
                <textarea name="keterangan" id="editKeterangan" class="form-control" rows="3" placeholder="Tambahkan catatan jika diperlukan..."></textarea>
            </div>

            <div class="modal-actions">
                <button type="button" class="btn btn-outline" onclick="tutupModal('modalEditStatus')">Batal</button>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
            </div>
        </form>
    </div>
</div>

<!-- =====================================================================
     MODAL: BUKTI (Upload / Lihat / Hapus Bukti)
     Terpisah dari Edit Status — bisa diakses kapan saja
===================================================================== -->
<div class="modal-overlay" id="modalBukti">
    <div class="modal-box modal-box-wide">
        <div class="modal-title">
            <i class="fas fa-paperclip" style="color:#15803d;"></i>
            Bukti Absensi —
            <span id="modalBuktiNama" style="color:var(--gray-500);font-weight:500;font-size:.9rem;"></span>
        </div>

        <!-- Info status -->
        <div id="buktiStatusInfo" style="margin-bottom:14px;padding:8px 12px;background:#f8fafc;border-radius:8px;font-size:.82rem;color:var(--gray-600);">
            Status: <strong id="buktiStatusLabel"></strong>
        </div>

        <!-- Preview bukti yang sudah ada -->
        <div id="buktiCurrentWrap" style="display:none;">
            <p style="font-size:.83rem;font-weight:700;color:var(--gray-700);margin-bottom:8px;">
                <i class="fas fa-check-circle" style="color:#15803d;"></i> Bukti Tersimpan
            </p>
            <div class="bukti-current-box">
                <div id="buktiCurrentThumb"></div>
                <div class="bukti-info">
                    <small>File bukti saat ini</small>
                    <strong id="buktiCurrentName"></strong>
                    <div style="margin-top:6px;display:flex;gap:8px;flex-wrap:wrap;">
                        <a id="buktiCurrentLink" href="#" target="_blank"
                           class="btn btn-outline btn-sm" style="font-size:.75rem;padding:3px 10px;">
                            <i class="fas fa-eye"></i> Lihat
                        </a>
                        <button type="button" class="btn-hapus-bukti" onclick="konfirmasiHapusBukti()">
                            <i class="fas fa-times-circle"></i> Hapus Bukti
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form upload baru -->
        <form method="POST" action="proses_absensi.php" enctype="multipart/form-data" id="formUploadBukti">
            <input type="hidden" name="aksi" value="upload_bukti">
            <input type="hidden" name="id" id="buktiAbsensiId">

            <p style="font-size:.83rem;font-weight:700;color:var(--gray-700);margin-bottom:8px;" id="buktiUploadLabel">
                <i class="fas fa-upload" style="color:#15803d;"></i> Upload Bukti Baru
            </p>

            <div class="upload-area" id="buktiUploadArea" onclick="document.getElementById('buktiFileInput').click()">
                <div style="font-size:1.8rem;margin-bottom:6px;">📎</div>
                <div style="font-weight:600;font-size:.88rem;color:var(--gray-700);">Klik untuk pilih file</div>
                <div style="font-size:.75rem;color:var(--gray-400);margin-top:4px;">JPG · PNG · PDF — maks. 5MB</div>
            </div>
            <input type="file" name="bukti_file" id="buktiFileInput" accept=".jpg,.jpeg,.png,.pdf" style="display:none;"
                   onchange="previewBuktiModal(this)">

            <div id="buktiFilePreview" style="display:none;margin-top:10px;"></div>

            <div class="modal-actions">
                <button type="button" class="btn btn-outline" onclick="tutupModal('modalBukti')">Batal</button>
                <button type="submit" class="btn" id="btnSimpanBukti"
                        style="background:linear-gradient(135deg,#15803d,#16a34a);color:white;" disabled>
                    <i class="fas fa-save"></i> Simpan Bukti
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Form hapus bukti tersembunyi -->
<form method="POST" action="proses_absensi.php" id="formHapusBukti" style="display:none;">
    <input type="hidden" name="aksi" value="hapus_bukti">
    <input type="hidden" name="id" id="hapusBuktiId">
</form>

<!-- MODAL: HAPUS MASSAL -->
<div class="modal-overlay" id="modalHapusMassal">
    <div class="modal-box modal-box-wide">
        <div class="modal-title"><i class="fas fa-trash-alt" style="color:#be123c;"></i> Hapus Data Absensi</div>
        <div style="background:#fff1f2;border:1px solid #fecdd3;border-radius:10px;padding:12px 14px;margin-bottom:18px;font-size:.83rem;color:#be123c;">
            <i class="fas fa-exclamation-triangle"></i> <strong>Data yang dihapus tidak dapat dikembalikan.</strong>
        </div>
        <form method="POST" action="proses_absensi.php" id="formHapusMassal" onsubmit="return konfirmasiHapusMassal()">
            <input type="hidden" name="aksi" value="hapus_massal">
            <div class="form-group" style="margin-bottom:16px;">
                <label style="font-size:.85rem;font-weight:700;color:var(--gray-700);margin-bottom:8px;display:block;">Hapus berdasarkan:</label>
                <div style="display:flex;gap:12px;">
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;padding:10px 16px;border:2px solid var(--gray-300);border-radius:10px;font-weight:600;flex:1;">
                        <input type="radio" name="hapus_tipe" value="bulan" checked onchange="toggleHapusTipe()">
                        <i class="fas fa-calendar-alt" style="color:#0369a1;"></i> Per Bulan
                    </label>
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;padding:10px 16px;border:2px solid var(--gray-300);border-radius:10px;font-weight:600;flex:1;">
                        <input type="radio" name="hapus_tipe" value="tanggal" onchange="toggleHapusTipe()">
                        <i class="fas fa-calendar-day" style="color:#7c3aed;"></i> Tanggal Tertentu
                    </label>
                </div>
            </div>
            <div class="form-group" id="inputBulan" style="margin-bottom:14px;">
                <label style="font-size:.85rem;font-weight:600;">Pilih Bulan</label>
                <input type="month" name="hapus_bulan" class="form-control" value="<?= date('Y-m') ?>">
            </div>
            <div class="form-group" id="inputTanggal" style="margin-bottom:14px;display:none;">
                <label style="font-size:.85rem;font-weight:600;">Pilih Tanggal</label>
                <input type="date" name="hapus_tanggal" class="form-control" value="<?= date('Y-m-d') ?>">
            </div>
            <div class="form-group" style="margin-bottom:0;">
                <label style="font-size:.85rem;font-weight:600;">Guru <span style="font-weight:400;color:var(--gray-400);">(kosongkan = semua guru)</span></label>
                <select name="hapus_guru_id" class="form-control">
                    <option value="0">— Semua Guru —</option>
                    <?php $guruList->data_seek(0); while ($g=$guruList->fetch_assoc()): ?>
                    <option value="<?= $g['id'] ?>"><?= htmlspecialchars($g['nama']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-outline" onclick="tutupModal('modalHapusMassal')">Batal</button>
                <button type="submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Hapus Sekarang</button>
            </div>
        </form>
    </div>
</div>

<!-- Form hapus satu -->
<form method="POST" action="proses_absensi.php" id="formHapus" style="display:none;">
    <input type="hidden" name="aksi" value="hapus">
    <input type="hidden" name="id" id="hapusId">
</form>

<script>
// ── Lightbox ────────────────────────────────────────────────
function bukaLightbox(src, nama, jam, tipe) {
    document.getElementById('lightbox-img').src = src;
    document.getElementById('lightbox').classList.add('active');
}
function tutupLightbox() { document.getElementById('lightbox').classList.remove('active'); }
document.addEventListener('keydown', e => { if (e.key==='Escape') tutupLightbox(); });

// ── Modal helpers ────────────────────────────────────────────
function tutupModal(id) { document.getElementById(id).classList.remove('active'); }
document.querySelectorAll('.modal-overlay').forEach(o => {
    o.addEventListener('click', e => { if (e.target===o) tutupModal(o.id); });
});
document.addEventListener('keydown', e => {
    if (e.key==='Escape') { tutupModal('modalEditStatus'); tutupModal('modalHapusMassal'); }
});

// ── Modal Bukti ──────────────────────────────────────────────
let currentBuktiFile = '';
const BASE_BUKTI_URL = '../uploads/bukti/';

function bukaModalBukti(id, nama, status, buktiFile) {
    currentBuktiFile = buktiFile;
    document.getElementById('buktiAbsensiId').value = id;
    document.getElementById('hapusBuktiId').value   = id;
    document.getElementById('modalBuktiNama').textContent = nama;

    const statusMap = {
        hadir:'✅ Hadir', terlambat:'⚠️ Terlambat',
        tidak_ada_keterangan:'❓ Tidak Ada Keterangan',
        izin:'📋 Izin', sakit:'🏥 Sakit'
    };
    document.getElementById('buktiStatusLabel').textContent = statusMap[status] || status;

    // Reset form
    document.getElementById('buktiFileInput').value = '';
    document.getElementById('buktiFilePreview').style.display = 'none';
    document.getElementById('buktiFilePreview').innerHTML = '';
    document.getElementById('buktiUploadArea').classList.remove('has-file');
    document.getElementById('btnSimpanBukti').disabled = true;

    // Tampilkan bukti yang sudah ada
    const currentWrap = document.getElementById('buktiCurrentWrap');
    if (buktiFile) {
        currentWrap.style.display = '';
        document.getElementById('buktiCurrentName').textContent = buktiFile;
        document.getElementById('buktiCurrentLink').href = BASE_BUKTI_URL + buktiFile;
        document.getElementById('buktiUploadLabel').innerHTML =
            '<i class="fas fa-exchange-alt" style="color:#0369a1;"></i> Ganti dengan Bukti Baru';

        // Thumb: gambar atau icon PDF
        const ext = buktiFile.split('.').pop().toLowerCase();
        const thumb = document.getElementById('buktiCurrentThumb');
        if (['jpg','jpeg','png'].includes(ext)) {
            thumb.innerHTML = '<img src="'+BASE_BUKTI_URL+buktiFile+'" onclick="bukaLightbox(\''+BASE_BUKTI_URL+buktiFile+'\')" style="width:56px;height:56px;object-fit:cover;border-radius:8px;border:2px solid #bbf7d0;cursor:pointer;" title="Klik untuk perbesar">';
        } else {
            thumb.innerHTML = '<div style="width:56px;height:56px;background:#fef2f2;border-radius:8px;display:flex;align-items:center;justify-content:center;"><i class="fas fa-file-pdf" style="font-size:1.6rem;color:#dc2626;"></i></div>';
        }
    } else {
        currentWrap.style.display = 'none';
        document.getElementById('buktiUploadLabel').innerHTML =
            '<i class="fas fa-upload" style="color:#15803d;"></i> Upload Bukti';
    }

    document.getElementById('modalBukti').classList.add('active');
}

function previewBuktiModal(input) {
    const preview = document.getElementById('buktiFilePreview');
    const area    = document.getElementById('buktiUploadArea');
    const btnSave = document.getElementById('btnSimpanBukti');
    const file    = input.files[0];
    if (!file) { btnSave.disabled = true; return; }
    if (file.size > 5*1024*1024) {
        alert('File terlalu besar. Maksimal 5MB.');
        input.value = ''; btnSave.disabled = true; return;
    }
    area.classList.add('has-file');
    preview.style.display = 'block';
    btnSave.disabled = false;

    if (file.type.startsWith('image/')) {
        const r = new FileReader();
        r.onload = e => {
            preview.innerHTML = '<img src="'+e.target.result+'" class="bukti-preview-img" style="max-height:160px;">'
                + '<div style="font-size:.75rem;color:var(--gray-500);margin-top:4px;">'+file.name+' ('+Math.round(file.size/1024)+' KB)</div>';
        };
        r.readAsDataURL(file);
    } else {
        preview.innerHTML = '<div style="background:#fef2f2;padding:10px 14px;border-radius:8px;font-size:.85rem;display:flex;align-items:center;gap:8px;">'
            +'<i class="fas fa-file-pdf" style="color:#dc2626;font-size:1.4rem;"></i>'
            +'<div><strong>'+file.name+'</strong><br><span style="color:var(--gray-400);font-size:.75rem;">'+Math.round(file.size/1024)+' KB</span></div></div>';
    }
}

function konfirmasiHapusBukti() {
    if (confirm('Hapus bukti yang tersimpan?\n\nFile bukti akan dihapus permanen.')) {
        document.getElementById('formHapusBukti').submit();
    }
}

// ── Modal Edit Status ────────────────────────────────────────
let existingBukti = '';
function bukaModalEditStatus(id, nama, status, keterangan, buktiFile, tanggal, guruId, jamMasuk, jamPulang) {
    existingBukti = buktiFile;
    document.getElementById('editStatusId').value   = id;
    document.getElementById('modalEditNama').textContent = nama;
    document.getElementById('editStatusVal').value  = status;
    document.getElementById('editKeterangan').value = keterangan;
    document.getElementById('editTanggal').value    = tanggal;
    document.getElementById('editGuruId').value     = guruId;
    document.getElementById('editJamMasuk').value   = jamMasuk;
    document.getElementById('editJamPulang').value  = jamPulang;
    document.getElementById('editBuktiFile').value = '';
    document.getElementById('editBuktiPreview').style.display = 'none';
    document.getElementById('editBuktiPreview').innerHTML = '';
    document.getElementById('editUploadArea').classList.remove('has-file');

    // Isi preview bukti yang sudah ada
    const buktiAda = document.getElementById('buktiAda');
    if (buktiFile) {
        buktiAda.style.display = '';
        document.getElementById('editBuktiCurrentName').textContent = buktiFile;
        document.getElementById('editBuktiCurrentLink').href = '../uploads/bukti/' + buktiFile;
        const ext = buktiFile.split('.').pop().toLowerCase();
        const thumb = document.getElementById('editBuktiCurrentThumb');
        if (['jpg','jpeg','png'].includes(ext)) {
            thumb.innerHTML = '<img src="../uploads/bukti/'+buktiFile+'" onclick="bukaLightbox(\'../uploads/bukti/'+buktiFile+'\')" style="width:50px;height:50px;object-fit:cover;border-radius:8px;border:2px solid #fde68a;cursor:pointer;">';
        } else {
            thumb.innerHTML = '<div style="width:50px;height:50px;background:#fef2f2;border-radius:8px;display:flex;align-items:center;justify-content:center;"><i class="fas fa-file-pdf" style="color:#dc2626;font-size:1.4rem;"></i></div>';
        }
    } else {
        buktiAda.style.display = 'none';
    }

    onStatusChange();
    document.getElementById('modalEditStatus').classList.add('active');
}

function onStatusChange() {
    const status  = document.getElementById('editStatusVal').value;
    const section = document.getElementById('buktiSection');
    const buktiAda = document.getElementById('buktiAda');
    if (status === 'izin' || status === 'sakit') {
        section.style.display = '';
        buktiAda.style.display = existingBukti ? '' : 'none';
    } else {
        section.style.display = 'none';
    }
}

function previewEditBukti(input) {
    const preview = document.getElementById('editBuktiPreview');
    const area    = document.getElementById('editUploadArea');
    const file    = input.files[0];
    if (!file) return;
    if (file.size > 5*1024*1024) { alert('File terlalu besar. Maks 5MB.'); input.value=''; return; }
    area.classList.add('has-file');
    preview.style.display = 'block';
    if (file.type.startsWith('image/')) {
        const r = new FileReader();
        r.onload = e => { preview.innerHTML = '<img src="'+e.target.result+'" class="bukti-preview-img">'; };
        r.readAsDataURL(file);
    } else {
        preview.innerHTML = '<div style="background:#f8fafc;padding:10px 14px;border-radius:8px;font-size:.85rem;"><i class="fas fa-file-pdf" style="color:#dc2626;"></i> '+file.name+'</div>';
    }
}

// ── Hapus satu ────────────────────────────────────────────────
function konfirmasiHapus(id, nama) {
    if (confirm('Hapus data absensi milik:\n"' + nama + '"?\n\nTindakan ini tidak dapat dibatalkan.')) {
        document.getElementById('hapusId').value = id;
        document.getElementById('formHapus').submit();
    }
}

// ── Hapus massal ─────────────────────────────────────────────
function bukaModalHapusMassal() { document.getElementById('modalHapusMassal').classList.add('active'); }
function toggleHapusTipe() {
    const tipe = document.querySelector('input[name="hapus_tipe"]:checked').value;
    document.getElementById('inputBulan').style.display   = tipe==='bulan'   ? '' : 'none';
    document.getElementById('inputTanggal').style.display = tipe==='tanggal' ? '' : 'none';
}
function konfirmasiHapusMassal() {
    const tipe = document.querySelector('input[name="hapus_tipe"]:checked').value;
    const nmBln = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    let label = '';
    if (tipe==='bulan') {
        const v = document.querySelector('input[name="hapus_bulan"]').value;
        if (!v) { alert('Pilih bulan.'); return false; }
        const p = v.split('-');
        label = 'bulan '+(nmBln[parseInt(p[1])]||p[1])+' '+p[0];
    } else {
        const d = document.querySelector('input[name="hapus_tanggal"]').value;
        if (!d) { alert('Pilih tanggal.'); return false; }
        label = 'tanggal '+d;
    }
    const guru = document.querySelector('select[name="hapus_guru_id"]');
    const guruInfo = guru.value==='0' ? 'semua guru' : guru.options[guru.selectedIndex].text;
    return confirm('⚠️ Konfirmasi Hapus Massal\n\nHapus seluruh data absensi untuk:\n- '+label+'\n- '+guruInfo+'\n\nTidak dapat dibatalkan! Lanjutkan?');
}
</script>

<script src="../js/mobile.js"></script>
</body>
</html>
