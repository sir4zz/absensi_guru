<?php
// Halaman klarifikasi sudah tidak digunakan pada v2.
// Status izin/sakit kini dikelola langsung oleh admin di halaman Data Absensi.
require_once '../includes/auth_admin.php';
header('Location: absensi.php');
exit;
