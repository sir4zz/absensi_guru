<?php
// ============================================
// KONFIGURASI DATABASE & KEAMANAN
// File: includes/config.php
// ============================================

date_default_timezone_set('Asia/Jakarta');

// ============================================
// SESSION SECURITY
// ============================================
ini_set('session.use_strict_mode', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.use_trans_sid', 0);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.gc_maxlifetime', 7200);

define('SESSION_TIMEOUT', 7200);

session_start();

if (isset($_SESSION['last_activity']) && (isset($_SESSION['guru_id']) || isset($_SESSION['admin_id']))) {
    if (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT) {
        session_unset();
        session_destroy();
        session_start();
        $_SESSION['timeout'] = true;
    }
}

if (isset($_SESSION['guru_id']) || isset($_SESSION['admin_id'])) {
    $_SESSION['last_activity'] = time();
}

// ============================================
// KONFIGURASI LOKASI SEKOLAH
// ============================================
define('SEKOLAH_LAT',   -6.2011);
define('SEKOLAH_LNG',   106.393);
define('RADIUS_METER',  200);
define('UPLOAD_SELFIE_DIR', '../uploads/selfie/');

// ============================================
// ATURAN JAM ABSENSI
// ============================================
define('JAM_MASUK_HADIR_AKHIR',      '08:30:00'); // <= 08:30 => status Hadir
define('JAM_MASUK_TERLAMBAT_AKHIR',  '09:00:00'); // <= 09:00 => status Terlambat
// > 09:00 => dikunci, sistem catat "Tidak Ada Keterangan"

define('JAM_CUTOFF', '09:00:00'); // Jam cut-off lazy insert
define('BATAS_KLARIFIKASI_HARI', 2);

// ============================================
// KONEKSI DATABASE
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'absensi_guru');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die('<div style="font-family:sans-serif;padding:20px;background:#fee;border:1px solid #f00;border-radius:8px;">
        <h3>Koneksi Database Gagal</h3>
        <p>' . htmlspecialchars($conn->connect_error) . '</p>
    </div>');
}

$conn->set_charset("utf8mb4");

// ============================================
// FUNGSI HELPER
// ============================================
function sanitize($conn, $data) {
    return $conn->real_escape_string(trim($data));
}
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}
function redirect($url) {
    header("Location: $url");
    exit();
}
function isLoggedIn() {
    return isset($_SESSION['guru_id']) && !empty($_SESSION['guru_id']);
}
function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

// ============================================
// TENTUKAN STATUS OTOMATIS BERDASARKAN JAM MASUK
// ============================================
function tentukanStatusMasuk($jam) {
    $t = strtotime($jam);
    if ($t <= strtotime(JAM_MASUK_HADIR_AKHIR)) {
        return 'hadir';
    } elseif ($t <= strtotime(JAM_MASUK_TERLAMBAT_AKHIR)) {
        return 'terlambat';
    }
    return 'terlambat'; // fallback (backend sudah blokir di atas jam ini)
}

// ============================================
// CEK APAKAH ABSEN MASUK MASIH DIIZINKAN (BACKEND)
// ============================================
function bisaAbsenMasuk() {
    return strtotime(date('H:i:s')) <= strtotime(JAM_MASUK_TERLAMBAT_AKHIR);
}

// ============================================
// LAZY CHECK "TIDAK ADA KETERANGAN"
// Guru yang tidak absen hingga JAM_CUTOFF dicatat otomatis sebagai tidak_ada_keterangan
// ============================================
function cekDanInsertTidakAdaKeterangan($conn) {
    $today = date('Y-m-d');
    $now   = date('H:i:s');
    if ($now < JAM_CUTOFF) return;

    $sql = "SELECT id FROM guru WHERE id NOT IN (
                SELECT guru_id FROM absensi WHERE tanggal = '$today'
            )";
    $result = $conn->query($sql);
    if (!$result || $result->num_rows === 0) return;

    while ($row = $result->fetch_assoc()) {
        $conn->query("INSERT IGNORE INTO absensi (guru_id, tanggal, status)
                      VALUES ({$row['id']}, '$today', 'tidak_ada_keterangan')");
    }
}

function getTodayDate()  { return date('Y-m-d'); }
function getCurrentTime(){ return date('H:i:s'); }

function formatDate($date) {
    $bulan = ['','Januari','Februari','Maret','April','Mei','Juni',
              'Juli','Agustus','September','Oktober','November','Desember'];
    $d = explode('-', $date);
    return $d[2] . ' ' . $bulan[(int)$d[1]] . ' ' . $d[0];
}

function formatTime($time) {
    if (!$time) return '-';
    return date('H:i', strtotime($time));
}
?>
