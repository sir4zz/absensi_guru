# Sistem Absensi Guru — Update v2

## Perubahan Utama

### Hak Akses Guru (guru/absensi.php)
- Guru hanya bisa: **Absen Masuk** dan **Absen Pulang**
- Tidak ada opsi Izin / Sakit di halaman guru
- Izin/Sakit hanya bisa diubah oleh Admin

### Aturan Jam Absen Masuk
| Jam | Status Otomatis |
|-----|----------------|
| 07:00 – 08:30 | **Hadir** |
| 08:31 – 09:00 | **Terlambat** |
| > 09:00 | Tombol **dikunci** (frontend + backend) |

Guru yang tidak absen hingga pukul 09:00 → dicatat otomatis: **Tidak Ada Keterangan**

### Hak Akses Admin (admin/absensi.php)
Admin dapat mengubah status menjadi:
- ✅ Hadir
- ⚠️ Terlambat
- ❓ Tidak Ada Keterangan
- 📋 Izin *(wajib upload bukti)*
- 🏥 Sakit *(wajib upload bukti)*

### Struktur Status Database
```sql
status ENUM('hadir','terlambat','tidak_ada_keterangan','izin','sakit')
```

## File yang Diubah
| File | Perubahan |
|------|-----------|
| `includes/config.php` | Konstanta jam baru, fungsi `tentukanStatusMasuk()`, `bisaAbsenMasuk()` |
| `guru/absensi.php` | Hanya 2 tombol: Masuk & Pulang. Auto-disable setelah 09:00 |
| `admin/absensi.php` | Status baru, validasi bukti wajib izin/sakit, ikon tombol |
| `admin/proses_absensi.php` | Validasi backend jam 09:00, validasi bukti wajib |
| `database.sql` | ENUM status diperbarui, field `updated_at` ditambah |

## Instalasi (Database Baru)
Import `database.sql` ke phpMyAdmin → jalankan semua.

## Migrasi (Database Sudah Ada)
Jalankan perintah ALTER di bagian bawah `database.sql`.

## Akun Default
| Role | Username/NIP | Password |
|------|-------------|---------|
| Admin | admin | password |
| Guru | 198501012010011001 | password |
