<?php
require_once '../includes/auth_guru.php';

cekDanInsertTidakAdaKeterangan($conn);

$today  = getTodayDate();
$now    = getCurrentTime();
$message     = '';
$messageType = '';

// ── Data absensi hari ini ───────────────────
$cekQ    = $conn->query("SELECT * FROM absensi WHERE guru_id = $guru_id AND tanggal = '$today'");
$absensi = $cekQ->num_rows > 0 ? $cekQ->fetch_assoc() : null;
$sudah_masuk  = !empty($absensi['jam_masuk']);
$sudah_pulang = !empty($absensi['jam_pulang']);
$status_hari_ini = $absensi['status'] ?? null;

// Helper: simpan selfie base64
function saveSelfie($base64data, $guru_id, $type) {
    $uploadDir = __DIR__ . '/../uploads/selfie/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
    if (preg_match('/^data:image\/(\w+);base64,/', $base64data, $matches)) {
        $ext  = strtolower($matches[1]) === 'jpeg' ? 'jpg' : strtolower($matches[1]);
        $data = base64_decode(substr($base64data, strpos($base64data, ',') + 1));
        if ($data === false) return null;
        $filename = 'selfie_' . $guru_id . '_' . $type . '_' . date('Ymd_His') . '.' . $ext;
        file_put_contents($uploadDir . $filename, $data);
        return $filename;
    }
    return null;
}

// ============================================================
// PROSES POST
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = sanitize($conn, $_POST['action'] ?? '');

    // ── ABSEN MASUK ─────────────────────────────────────────
    if ($action === 'masuk') {

        // Jika guru punya record tidak_ada_keterangan tapi masih belum lewat jam cutoff,
        // izinkan absen masuk dengan memperlakukan seperti belum absen
        if ($absensi && $absensi['status'] === 'tidak_ada_keterangan' && empty($absensi['jam_masuk']) && bisaAbsenMasuk()) {
            $sudah_masuk = false;
        }

        // Validasi backend: jam sudah lewat 09:00?
        if (!bisaAbsenMasuk()) {
            $message     = '🔒 Waktu absen masuk sudah berakhir (setelah pukul 09:00). Hubungi admin jika diperlukan.';
            $messageType = 'danger';

        } elseif ($sudah_masuk) {
            $message     = 'Anda sudah melakukan absen masuk hari ini.';
            $messageType = 'warning';

        } else {
            $jam    = getCurrentTime();
            $status = sanitize($conn, tentukanStatusMasuk($jam)); // 'hadir' atau 'terlambat'

            $foto_b64 = $_POST['foto'] ?? '';
            $lat      = floatval($_POST['lat'] ?? 0);
            $lng      = floatval($_POST['lng'] ?? 0);
            $fotoFile = saveSelfie($foto_b64, $guru_id, 'masuk');
            $fotoSql  = $fotoFile ? "'" . sanitize($conn, $fotoFile) . "'" : 'NULL';
            $latSql   = ($lat != 0) ? $lat : 'NULL';
            $lngSql   = ($lng != 0) ? $lng : 'NULL';

            if (!$absensi) {
                $conn->query("INSERT INTO absensi (guru_id, tanggal, status, jam_masuk, foto_masuk, lat_masuk, lng_masuk)
                              VALUES ($guru_id, '$today', '$status', '$jam', $fotoSql, $latSql, $lngSql)");
            } else {
                $conn->query("UPDATE absensi SET status='$status', jam_masuk='$jam',
                              foto_masuk=$fotoSql, lat_masuk=$latSql, lng_masuk=$lngSql
                              WHERE id={$absensi['id']}");
            }

            $icon    = ($status === 'terlambat') ? '⚠️' : '✅';
            $label   = ($status === 'terlambat') ? 'Terlambat' : 'Tepat Waktu';
            $message = "$icon Absen masuk dicatat pukul " . formatTime($jam) . " — $label.";
            $messageType = ($status === 'terlambat') ? 'warning' : 'success';

            // Cabut izin khusus jika ada
            $conn->query("DELETE FROM izin_absen WHERE guru_id=$guru_id AND tanggal='$today'");
        }

    // ── ABSEN PULANG ─────────────────────────────────────────
    } elseif ($action === 'pulang') {

        if (!$sudah_masuk) {
            $message     = 'Anda belum absen masuk. Harap absen masuk terlebih dahulu.';
            $messageType = 'danger';

        } elseif ($sudah_pulang) {
            $message     = 'Anda sudah melakukan absen pulang hari ini.';
            $messageType = 'warning';

        } else {
            $jam = getCurrentTime();

            $foto_b64 = $_POST['foto'] ?? '';
            $lat      = floatval($_POST['lat'] ?? 0);
            $lng      = floatval($_POST['lng'] ?? 0);
            $fotoFile = saveSelfie($foto_b64, $guru_id, 'pulang');
            $fotoSql  = $fotoFile ? "'" . sanitize($conn, $fotoFile) . "'" : 'NULL';
            $latSql   = ($lat != 0) ? $lat : 'NULL';
            $lngSql   = ($lng != 0) ? $lng : 'NULL';

            $conn->query("UPDATE absensi SET jam_pulang='$jam',
                          foto_pulang=$fotoSql, lat_pulang=$latSql, lng_pulang=$lngSql
                          WHERE id={$absensi['id']}");

            $message     = '✅ Absen pulang dicatat pukul ' . formatTime($jam) . '.';
            $messageType = 'success';
        }
    }

    // Refresh data setelah proses
    $cekQ2   = $conn->query("SELECT * FROM absensi WHERE guru_id = $guru_id AND tanggal = '$today'");
    $absensi = $cekQ2->num_rows > 0 ? $cekQ2->fetch_assoc() : null;
    $sudah_masuk  = !empty($absensi['jam_masuk']);
    $sudah_pulang = !empty($absensi['jam_pulang']);
    $status_hari_ini = $absensi['status'] ?? null;
    $now = getCurrentTime();
}

// Frontend: apakah tombol masuk seharusnya dikunci?
// Dikunci jika: jam sudah lewat 09:00, ATAU sudah absen masuk,
// KECUALI guru punya status tidak_ada_keterangan dan jam masih sebelum cutoff
$masuk_dikunci = !bisaAbsenMasuk() || ($sudah_masuk && !($absensi && $absensi['status'] === 'tidak_ada_keterangan' && empty($absensi['jam_masuk']) && bisaAbsenMasuk()));
// Jam cut-off untuk JS countdown (format HH:MM:SS)
$jam_cutoff_js = JAM_MASUK_TERLAMBAT_AKHIR;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi - Sistem Absensi Guru</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        .absen-big-btn {
            display: flex; flex-direction: column; align-items: center;
            justify-content: center; gap: 10px; padding: 32px 20px;
            border-radius: 18px; border: 2.5px solid; cursor: pointer;
            transition: all 0.2s; width: 100%; background: white; text-align: center;
        }
        .absen-big-btn.masuk  { border-color: var(--success); }
        .absen-big-btn.pulang { border-color: var(--danger); }
        .absen-big-btn:not(:disabled):hover { transform: translateY(-3px); }
        .absen-big-btn.masuk:not(:disabled):hover  { background: var(--success); color: white; box-shadow: 0 10px 28px rgba(16,185,129,.3); }
        .absen-big-btn.pulang:not(:disabled):hover { background: var(--danger);  color: white; box-shadow: 0 10px 28px rgba(239,68,68,.3); }
        .absen-big-btn:disabled { opacity: 0.4; cursor: not-allowed; background: var(--gray-100) !important; }
        .absen-big-btn .btn-icon  { font-size: 40px; }
        .absen-big-btn .btn-label { font-size: 1.0625rem; font-weight: 800; }
        .absen-big-btn .btn-sub   { font-size: 0.8125rem; opacity: 0.75; }
        .absen-big-btn.done-masuk  { background: #d1fae5; border-color: var(--success); cursor: default; }
        .absen-big-btn.done-pulang { background: #fee2e2; border-color: var(--danger);  cursor: default; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
        @media(max-width:600px) { .grid-2 { grid-template-columns: 1fr; } }

        /* Status panel */
        .status-panel {
            display: flex; gap: 14px; flex-wrap: wrap;
            background: var(--gray-50); border-radius: 14px;
            padding: 18px 20px; margin-top: 20px;
            border: 1.5px solid var(--gray-200);
        }
        .status-item { flex: 1; min-width: 120px; }
        .status-label { font-size: 0.75rem; color: var(--gray-500); font-weight: 600; text-transform: uppercase; margin-bottom: 4px; }
        .status-val   { font-size: 1rem; font-weight: 700; }

        /* Jam countdown */
        .jam-info-bar {
            display: flex; align-items: center; gap: 10px;
            padding: 12px 16px; border-radius: 10px; font-size: 0.875rem; font-weight: 600;
            margin-bottom: 18px;
        }
        .jam-info-bar.ok     { background: #d1fae5; color: #065f46; }
        .jam-info-bar.warn   { background: #fef3c7; color: #92400e; }
        .jam-info-bar.locked { background: #fee2e2; color: #991b1b; }

        /* MODAL */
        .modal-overlay {
            display: none; position: fixed; inset: 0;
            background: rgba(0,0,0,0.72); z-index: 9999;
            align-items: center; justify-content: center;
        }
        .modal-overlay.active { display: flex; }
        .modal-box {
            background: white; border-radius: 20px; padding: 28px;
            width: 95%; max-width: 460px; box-shadow: 0 20px 60px rgba(0,0,0,.4);
            animation: scaleIn .22s ease;
        }
        @keyframes scaleIn { from{transform:scale(.85);opacity:0} to{transform:scale(1);opacity:1} }
        .modal-title { font-size: 1.1rem; font-weight: 800; margin-bottom: 14px; display: flex; align-items: center; gap: 8px; }
        #camera-video { width: 100%; border-radius: 12px; background: #111; aspect-ratio: 4/3; object-fit: cover; display: block; }
        #camera-canvas { display: none; }
        #foto-preview  { width: 100%; border-radius: 12px; display: none; aspect-ratio: 4/3; object-fit: cover; }
        .gps-status {
            display: flex; align-items: center; gap: 10px;
            padding: 11px 14px; border-radius: 10px; margin-top: 12px;
            font-size: 0.855rem; font-weight: 600; line-height: 1.4;
        }
        .gps-status.loading { background: #fef3c7; color: #92400e; }
        .gps-status.ok      { background: #d1fae5; color: #065f46; }
        .gps-status.error   { background: #fee2e2; color: #991b1b; }
        .gps-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
        .gps-status.loading .gps-dot { background: #f59e0b; animation: pulse 1s infinite; }
        .gps-status.ok      .gps-dot { background: #10b981; }
        .gps-status.error   .gps-dot { background: #ef4444; }
        @keyframes pulse { 0%,100%{opacity:1}50%{opacity:.35} }
        .cam-btn-row { display: flex; gap: 8px; margin-top: 12px; flex-wrap: wrap; }
        .btn-cam { flex: 1; min-width: 100px; padding: 11px 8px; border-radius: 10px; border: none; font-weight: 700; cursor: pointer; font-size: 0.9rem; transition: all .18s; }
        .btn-cam.capture { background: var(--primary); color: white; }
        .btn-cam.retake  { background: var(--gray-200); color: var(--gray-700); }
        .btn-cam.confirm { background: var(--success); color: white; }
        .btn-cam.cancel  { background: var(--gray-100); color: var(--gray-600); border: 1.5px solid var(--gray-300); }
        .btn-cam:disabled { opacity: .4; cursor: not-allowed; }
    </style>
</head>
<body>
<div class="app-layout">
    <!-- MOBILE HEADER -->
    <div class="mobile-header">
        <button class="hamburger-btn" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>
        <div class="mh-brand">
            <div class="mh-icon">✅</div>
            <span>Absensi</span>
        </div>
        <div class="mh-actions">
            <a href="../logout.php" class="mh-logout-btn" onclick="return confirm('Yakin ingin keluar?')" title="Keluar">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>
    <div class="sidebar-overlay"></div>

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-brand">
                <div class="brand-icon">🏫</div>
                <div class="brand-text"><h2>Absensi Guru</h2><p>Portal Guru</p></div>
            </div>
        </div>
        <div class="sidebar-user">
            <div class="user-avatar"><?= strtoupper(substr($guru['nama'], 0, 2)) ?></div>
            <div class="user-info">
                <h4><?= htmlspecialchars(explode(',', $guru['nama'])[0]) ?></h4>
                <p>NIP: <?= htmlspecialchars($guru['nip']) ?></p>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Menu Utama</div>
                <a href="dashboard.php" class="nav-item"><i class="fas fa-home nav-icon"></i> Dashboard</a>
                <a href="absensi.php" class="nav-item active"><i class="fas fa-fingerprint nav-icon"></i> Absensi</a>
                <a href="riwayat.php" class="nav-item"><i class="fas fa-history nav-icon"></i> Riwayat</a>
            </div>
            <div class="nav-section">
                <div class="nav-section-title">Akun</div>
                <a href="ganti_password.php" class="nav-item"><i class="fas fa-key nav-icon"></i> Ganti Password</a>
            </div>
        </nav>
        <div class="sidebar-footer">
            <a href="../logout.php" class="nav-item" onclick="return confirm('Yakin ingin keluar?')">
                <i class="fas fa-sign-out-alt nav-icon"></i> Keluar
            </a>
        </div>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left">
                <h1>Absensi Harian</h1>
                <p>Catat kehadiran Anda hari ini</p>
            </div>
            <div class="topbar-date">
                <i class="fas fa-calendar-day"></i>
                <?= formatDate($today) ?>
            </div>
        </div>

        <?php if ($message): ?>
        <div class="alert alert-<?= $messageType ?>">
            <i class="fas fa-<?= $messageType==='success'?'check-circle':($messageType==='danger'?'times-circle':'exclamation-triangle') ?>"></i>
            <?= $message ?>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-fingerprint"></i> Absensi Hari Ini</div>
                <span class="badge badge-primary" id="jam-sekarang"><?= date('H:i:s') ?></span>
            </div>
            <div class="card-body">

                <!-- Info batas waktu absen masuk -->
                <div class="jam-info-bar <?= $masuk_dikunci ? 'locked' : (strtotime($now) > strtotime(JAM_MASUK_HADIR_AKHIR) ? 'warn' : 'ok') ?>" id="jam-info-bar">
                    <?php if ($masuk_dikunci): ?>
                        <i class="fas fa-lock"></i>
                        <span>Waktu absen masuk sudah berakhir sejak pukul 09:00. Hubungi admin jika perlu perubahan.</span>
                    <?php elseif (strtotime($now) > strtotime(JAM_MASUK_HADIR_AKHIR)): ?>
                        <i class="fas fa-exclamation-triangle"></i>
                        <span>Sudah lewat pukul 08:30 — absen masuk akan dicatat <strong>Terlambat</strong>. Batas akhir: <strong>09:00</strong>.</span>
                    <?php else: ?>
                        <i class="fas fa-clock"></i>
                        <span>Absen masuk tepat waktu hingga <strong>08:30</strong>. Batas akhir absen: <strong>09:00</strong>.</span>
                    <?php endif; ?>
                </div>

                <!-- Dua tombol utama: Masuk & Pulang -->
                <div class="grid-2">

                    <!-- Absen Masuk -->
                    <?php if ($sudah_masuk): ?>
                        <div class="absen-big-btn done-masuk">
                            <span class="btn-icon">✅</span>
                            <span class="btn-label" style="color:var(--success);">Sudah Masuk</span>
                            <span class="btn-sub" style="color:var(--success);"><?= formatTime($absensi['jam_masuk']) ?></span>
                            <span class="badge <?= $absensi['status']==='terlambat'?'badge-danger':'badge-success' ?>" style="font-size:0.72rem;">
                                <?= $absensi['status'] === 'terlambat' ? 'Terlambat' : 'Tepat Waktu' ?>
                            </span>
                        </div>
                    <?php elseif ($masuk_dikunci): ?>
                        <button type="button" class="absen-big-btn masuk" disabled id="btn-masuk">
                            <span class="btn-icon">🔒</span>
                            <span class="btn-label" style="color:var(--gray-500);">Absen Masuk</span>
                            <span class="btn-sub" style="color:var(--gray-500);">Dikunci sejak 09:00</span>
                        </button>
                    <?php else: ?>
                        <button type="button" class="absen-big-btn masuk" onclick="bukaModal('masuk')" id="btn-masuk">
                            <span class="btn-icon">🟢</span>
                            <span class="btn-label" style="color:var(--success);">Absen Masuk</span>
                            <span class="btn-sub" style="color:var(--success);">Tepat waktu ≤ 08:30 | Batas 09:00</span>
                        </button>
                    <?php endif; ?>

                    <!-- Absen Pulang -->
                    <?php if ($sudah_pulang): ?>
                        <div class="absen-big-btn done-pulang">
                            <span class="btn-icon">✅</span>
                            <span class="btn-label" style="color:var(--danger);">Sudah Pulang</span>
                            <span class="btn-sub" style="color:var(--danger);"><?= formatTime($absensi['jam_pulang']) ?></span>
                        </div>
                    <?php elseif (!$sudah_masuk): ?>
                        <button type="button" class="absen-big-btn pulang" disabled>
                            <span class="btn-icon">🔒</span>
                            <span class="btn-label" style="color:var(--gray-400);">Absen Pulang</span>
                            <span class="btn-sub" style="color:var(--gray-400);">Absen masuk dulu</span>
                        </button>
                    <?php else: ?>
                        <button type="button" class="absen-big-btn pulang" onclick="bukaModal('pulang')">
                            <span class="btn-icon">🔴</span>
                            <span class="btn-label" style="color:var(--danger);">Absen Pulang</span>
                            <span class="btn-sub" style="color:var(--danger);">Klik untuk absen pulang</span>
                        </button>
                    <?php endif; ?>
                </div>

                <!-- Status ringkasan -->
                <?php if ($absensi): ?>
                <div class="status-panel">
                    <div class="status-item">
                        <div class="status-label">Status</div>
                        <div class="status-val">
                            <?php
                            $statusMap = [
                                'hadir'               => ['✅ Hadir',               'var(--success)'],
                                'terlambat'           => ['⚠️ Terlambat',           '#d97706'],
                                'tidak_ada_keterangan'=> ['❓ Tidak Ada Keterangan','var(--gray-600)'],
                                'izin'                => ['📋 Izin',                'var(--primary)'],
                                'sakit'               => ['🏥 Sakit',               'var(--warning)'],
                            ];
                            [$sLabel, $sColor] = $statusMap[$status_hari_ini] ?? ['—', 'var(--gray-400)'];
                            echo "<span style='color:$sColor;'>$sLabel</span>";
                            ?>
                        </div>
                    </div>
                    <div class="status-item">
                        <div class="status-label">Jam Masuk</div>
                        <div class="status-val"><?= $sudah_masuk ? formatTime($absensi['jam_masuk']) : '—' ?></div>
                    </div>
                    <div class="status-item">
                        <div class="status-label">Jam Pulang</div>
                        <div class="status-val"><?= $sudah_pulang ? formatTime($absensi['jam_pulang']) : '—' ?></div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- Info Aturan -->
        <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-info-circle"></i> Aturan Absensi</div></div>
            <div class="card-body">
                <ul style="list-style:none;display:flex;flex-direction:column;gap:10px;">
                    <li style="display:flex;gap:10px;"><span style="color:var(--success);">✅</span> Jam <strong>07:00 – 08:30</strong> → Status <strong>Hadir</strong></li>
                    <li style="display:flex;gap:10px;"><span style="color:#d97706;">⚠️</span> Jam <strong>08:31 – 09:00</strong> → Status <strong>Terlambat</strong></li>
                    <li style="display:flex;gap:10px;"><span style="color:var(--danger);">🔒</span> Setelah <strong>09:00</strong> → Tombol absen masuk <strong>dikunci</strong></li>
                    <li style="display:flex;gap:10px;"><span style="color:var(--primary);">📋</span> Izin/Sakit hanya bisa diubah oleh <strong>Admin</strong></li>
                    <li style="display:flex;gap:10px;"><span style="color:var(--success);">✅</span> Absen masuk hanya <strong>1 kali</strong> per hari</li>
                    <li style="display:flex;gap:10px;"><span style="color:var(--success);">✅</span> Absen pulang hanya setelah <strong>absen masuk</strong></li>
                </ul>
            </div>
        </div>

    </main>
</div>

<!-- ===================== MODAL KAMERA + GPS ===================== -->
<div class="modal-overlay" id="modal-absen">
    <div class="modal-box">
        <div class="modal-title">
            <span id="modal-icon">📸</span>
            <span id="modal-label">Absen Masuk</span>
        </div>
        <video id="camera-video" autoplay playsinline muted></video>
        <canvas id="camera-canvas"></canvas>
        <img id="foto-preview" alt="Foto Selfie">
        <div class="gps-status loading" id="gps-status">
            <span class="gps-dot"></span>
            <span id="gps-text">Mengambil lokasi GPS...</span>
        </div>
        <div class="cam-btn-row">
            <button class="btn-cam capture" id="btn-capture" onclick="ambilFoto()" disabled>
                <i class="fas fa-camera"></i> Ambil Foto
            </button>
            <button class="btn-cam retake" id="btn-retake" onclick="ulangiKamera()" style="display:none;">
                <i class="fas fa-redo"></i> Ulangi
            </button>
            <button class="btn-cam confirm" id="btn-confirm" onclick="konfirmasiAbsen()" style="display:none;" disabled>
                <i class="fas fa-check"></i> Konfirmasi
            </button>
            <button class="btn-cam cancel" onclick="tutupModal()">
                <i class="fas fa-times"></i> Batal
            </button>
        </div>
        <form id="form-absen" method="POST" style="display:none;">
            <input type="hidden" name="action" id="input-action">
            <input type="hidden" name="foto"   id="input-foto">
            <input type="hidden" name="lat"    id="input-lat">
            <input type="hidden" name="lng"    id="input-lng">
        </form>
    </div>
</div>

<script>
const SEKOLAH_LAT = <?= SEKOLAH_LAT ?>;
const SEKOLAH_LNG = <?= SEKOLAH_LNG ?>;
const RADIUS_M    = <?= RADIUS_METER ?>;
const JAM_CUTOFF  = '<?= JAM_MASUK_TERLAMBAT_AKHIR ?>'; // '09:00:00'

let stream = null, fotoDataUrl = null;
let gpsLat = null, gpsLng = null, gpsOk = false;
let currentAction = '';

// ── Jam real-time + auto-kunci tombol masuk ──────────────────
function padZ(n) { return n < 10 ? '0' + n : n; }

function jamSekarang() {
    const d = new Date();
    return padZ(d.getHours()) + ':' + padZ(d.getMinutes()) + ':' + padZ(d.getSeconds());
}

function updateJamDisplay() {
    const el = document.getElementById('jam-sekarang');
    if (el) el.textContent = jamSekarang().substring(0, 5);

    // Auto kunci tombol masuk di frontend saat jam sudah lewat 09:00
    const [cH, cM, cS] = JAM_CUTOFF.split(':').map(Number);
    const d = new Date();
    const cutoffMs = (cH * 3600 + cM * 60 + cS) * 1000;
    const nowMs    = (d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds()) * 1000;

    const btnMasuk = document.getElementById('btn-masuk');
    if (btnMasuk && !btnMasuk.classList.contains('done-masuk') && nowMs > cutoffMs) {
        btnMasuk.disabled = true;
        btnMasuk.querySelector('.btn-icon').textContent  = '🔒';
        btnMasuk.querySelector('.btn-label').textContent = 'Absen Masuk';
        btnMasuk.querySelector('.btn-sub').textContent   = 'Dikunci sejak 09:00';
        const bar = document.getElementById('jam-info-bar');
        if (bar) {
            bar.className = 'jam-info-bar locked';
            bar.innerHTML = '<i class="fas fa-lock"></i><span>Waktu absen masuk sudah berakhir. Hubungi admin jika perlu perubahan.</span>';
        }
    }
}
setInterval(updateJamDisplay, 1000);
updateJamDisplay();

// ── GPS & Kamera ──────────────────────────────────────────────
function hitungJarak(lat1, lng1, lat2, lng2) {
    const R = 6371000;
    const dLat = (lat2-lat1)*Math.PI/180;
    const dLng = (lng2-lng1)*Math.PI/180;
    const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLng/2)**2;
    return R*2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function bukaModal(action) {
    // Cek lagi jam sebelum buka modal (double-check frontend)
    const [cH, cM, cS] = JAM_CUTOFF.split(':').map(Number);
    const d = new Date();
    const nowSec    = d.getHours() * 3600 + d.getMinutes() * 60 + d.getSeconds();
    const cutoffSec = cH * 3600 + cM * 60 + cS;
    if (action === 'masuk' && nowSec > cutoffSec) {
        alert('⏰ Waktu absen masuk sudah habis (setelah 09:00).\nHubungi admin jika diperlukan.');
        return;
    }

    currentAction = action;
    fotoDataUrl = null; gpsLat = gpsLng = null; gpsOk = false;
    document.getElementById('modal-absen').classList.add('active');
    document.getElementById('input-action').value = action;
    document.getElementById('modal-label').textContent = action === 'masuk' ? 'Absen Masuk' : 'Absen Pulang';
    document.getElementById('modal-icon').textContent  = action === 'masuk' ? '🟢' : '🔴';
    tampilkanVideo();
    mulaiGPS();
}

async function tampilkanVideo() {
    const video  = document.getElementById('camera-video');
    const preview = document.getElementById('foto-preview');
    const btnCap = document.getElementById('btn-capture');
    const btnRet = document.getElementById('btn-retake');
    const btnCon = document.getElementById('btn-confirm');
    preview.style.display = 'none'; video.style.display = 'block';
    btnRet.style.display  = 'none'; btnCon.style.display = 'none';
    btnCap.style.display  = ''; btnCap.disabled = true;
    try {
        stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'user', width:{ideal:640}, height:{ideal:480} }, audio: false
        });
        video.srcObject = stream;
        video.onloadedmetadata = () => { video.play(); btnCap.disabled = false; };
    } catch(err) {
        alert('❌ Kamera tidak dapat diakses.\n' + err.message);
        tutupModal();
    }
}

function mulaiGPS() {
    const el = document.getElementById('gps-status');
    const tx = document.getElementById('gps-text');
    el.className = 'gps-status loading'; tx.textContent = 'Mengambil lokasi GPS...';
    gpsOk = false; updateTombolKonfirmasi();
    if (!navigator.geolocation) { el.className='gps-status error'; tx.textContent='❌ Browser tidak mendukung GPS.'; return; }
    navigator.geolocation.getCurrentPosition(pos => {
        gpsLat = pos.coords.latitude; gpsLng = pos.coords.longitude;
        const jarak = Math.round(hitungJarak(gpsLat, gpsLng, SEKOLAH_LAT, SEKOLAH_LNG));
        if (jarak <= RADIUS_M) {
            el.className='gps-status ok'; tx.textContent='✅ Lokasi valid — '+jarak+'m dari sekolah'; gpsOk=true;
        } else {
            el.className='gps-status error'; tx.textContent='❌ Di luar area ('+jarak+'m dari sekolah, maks. '+RADIUS_M+'m)'; gpsOk=false;
        }
        updateTombolKonfirmasi();
    }, err => {
        el.className='gps-status error';
        const p={1:'Izin lokasi ditolak.',2:'Posisi tidak tersedia.',3:'Waktu habis, coba lagi.'};
        tx.textContent='❌ '+(p[err.code]||'GPS error.'); gpsOk=false; updateTombolKonfirmasi();
    }, { enableHighAccuracy:true, timeout:15000, maximumAge:0 });
}

function ambilFoto() {
    const video = document.getElementById('camera-video');
    const canvas = document.getElementById('camera-canvas');
    const preview = document.getElementById('foto-preview');
    canvas.width = video.videoWidth||640; canvas.height = video.videoHeight||480;
    const ctx = canvas.getContext('2d');
    ctx.translate(canvas.width,0); ctx.scale(-1,1);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    fotoDataUrl = canvas.toDataURL('image/jpeg', 0.85);
    preview.src = fotoDataUrl;
    video.style.display='none'; preview.style.display='block';
    document.getElementById('btn-capture').style.display='none';
    document.getElementById('btn-retake').style.display='';
    document.getElementById('btn-confirm').style.display='';
    if (stream) stream.getTracks().forEach(t=>t.stop());
    updateTombolKonfirmasi();
}

function ulangiKamera() { fotoDataUrl=null; tampilkanVideo(); }

function updateTombolKonfirmasi() {
    const btn = document.getElementById('btn-confirm');
    if (btn) btn.disabled = !(fotoDataUrl && gpsOk);
}

function konfirmasiAbsen() {
    if (!fotoDataUrl) { alert('Harap ambil foto selfie terlebih dahulu.'); return; }
    if (!gpsOk)       { alert('Lokasi Anda di luar area sekolah.'); return; }
    const label = currentAction==='masuk'?'ABSEN MASUK':'ABSEN PULANG';
    if (!confirm('Konfirmasi '+label+' sekarang?')) return;
    document.getElementById('input-foto').value = fotoDataUrl;
    document.getElementById('input-lat').value  = gpsLat||'';
    document.getElementById('input-lng').value  = gpsLng||'';
    const btn = document.getElementById('btn-confirm');
    btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Menyimpan...';
    document.getElementById('form-absen').submit();
}

function tutupModal() {
    if (stream) { stream.getTracks().forEach(t=>t.stop()); stream=null; }
    document.getElementById('modal-absen').classList.remove('active');
    fotoDataUrl=null;
}

document.getElementById('modal-absen').addEventListener('click', function(e) {
    if (e.target === this) tutupModal();
});
</script>

<script src="../js/mobile.js"></script>
</body>
</html>
