<?php
require_once '../includes/auth_guru.php';

cekDanInsertTidakAdaKeterangan($conn);

$today = getTodayDate();

$result = $conn->query("SELECT * FROM absensi WHERE guru_id = $guru_id AND tanggal = '$today'");
$absensi_hari_ini = $result->num_rows > 0 ? $result->fetch_assoc() : null;
$status_hari_ini  = $absensi_hari_ini['status'] ?? null;
$sudah_masuk      = !empty($absensi_hari_ini['jam_masuk']);
$sudah_pulang     = !empty($absensi_hari_ini['jam_pulang']);
$sudah_izin       = ($status_hari_ini === 'izin');
$sudah_sakit      = ($status_hari_ini === 'sakit');
$sudah_tak        = ($status_hari_ini === 'tidak_ada_keterangan');
$sudah_terlambat  = ($status_hari_ini === 'terlambat');

$riwayat = $conn->query("SELECT * FROM absensi WHERE guru_id = $guru_id ORDER BY tanggal DESC, id DESC LIMIT 10");

$bulan_ini     = date('Y-m');
$total_hadir   = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE guru_id=$guru_id AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini' AND (status='hadir' OR status='terlambat') AND jam_masuk IS NOT NULL")->fetch_assoc()['t'];
$total_izin    = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE guru_id=$guru_id AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini' AND status='izin'")->fetch_assoc()['t'];
$total_sakit   = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE guru_id=$guru_id AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini' AND status='sakit'")->fetch_assoc()['t'];
$total_lengkap = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE guru_id=$guru_id AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini' AND jam_masuk IS NOT NULL AND jam_pulang IS NOT NULL")->fetch_assoc()['t'];
$total_tak     = $conn->query("SELECT COUNT(*) as t FROM absensi WHERE guru_id=$guru_id AND DATE_FORMAT(tanggal,'%Y-%m')='$bulan_ini' AND status='tidak_ada_keterangan'")->fetch_assoc()['t'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Guru - Sistem Absensi</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="app-layout">
    <div class="mobile-header">
        <button class="hamburger-btn" aria-label="Toggle menu">
            <span></span><span></span><span></span>
        </button>
        <div class="mh-brand">
            <div class="mh-icon">📊</div>
            <span>Selamat Datang! 👋</span>
        </div>
        <div class="mh-actions">
            <a href="../logout.php" class="mh-logout-btn" onclick="return confirm('Yakin ingin keluar?')" title="Keluar">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>
    <div class="sidebar-overlay"></div>

    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-brand">
                <div class="brand-icon">🏫</div>
                <div class="brand-text"><h2>Absensi Guru</h2><p>Portal Guru</p></div>
            </div>
        </div>
        <div class="sidebar-user">
            <div class="user-avatar"><?= strtoupper(substr($guru['nama'], 0, 2)) ?></div>
            <div class="user-info">
                <h4><?= htmlspecialchars(explode(',', $guru['nama'])[0]) ?></h4>
                <p>NIP: <?= htmlspecialchars($guru['nip']) ?></p>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-section">
                <div class="nav-section-title">Menu Utama</div>
                <a href="dashboard.php" class="nav-item active"><i class="fas fa-home nav-icon"></i> Dashboard</a>
                <a href="absensi.php" class="nav-item"><i class="fas fa-fingerprint nav-icon"></i> Absensi</a>
                <a href="riwayat.php" class="nav-item"><i class="fas fa-history nav-icon"></i> Riwayat Absensi</a>
            </div>
            <div class="nav-section">
                <div class="nav-section-title">Akun</div>
                <a href="ganti_password.php" class="nav-item"><i class="fas fa-key nav-icon"></i> Ganti Password</a>
            </div>
        </nav>
        <div class="sidebar-footer">
            <a href="../logout.php" class="nav-item" onclick="return confirm('Yakin ingin keluar?')">
                <i class="fas fa-sign-out-alt nav-icon"></i> Keluar
            </a>
        </div>
    </aside>

    <main class="main-content">
        <div class="topbar">
            <div class="topbar-left">
                <h1>Selamat Datang! 👋</h1>
                <p><?= htmlspecialchars($guru['nama']) ?></p>
            </div>
            <div class="topbar-date">
                <i class="fas fa-calendar-day"></i>
                <?= formatDate($today) ?>
            </div>
        </div>

        <!-- Status Kehadiran Hari Ini -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-clipboard-check"></i> Status Kehadiran Hari Ini</div>
                <?php
                $badgeMap = [
                    'hadir'               => ['badge-success',   '✅ Hadir'],
                    'terlambat'           => ['badge-warning',   '⚠️ Terlambat'],
                    'izin'                => ['badge-primary',   '📋 Izin'],
                    'sakit'               => ['badge-warning',   '🏥 Sakit'],
                    'tidak_ada_keterangan'=> ['badge-secondary', '❓ Tidak Ada Ket.'],
                ];
                if ($status_hari_ini && isset($badgeMap[$status_hari_ini])):
                    [$bc, $bl] = $badgeMap[$status_hari_ini];
                ?>
                    <span class="badge <?= $bc ?>"><?= $bl ?></span>
                <?php elseif ($sudah_masuk && $sudah_pulang): ?>
                    <span class="badge badge-success">✅ Hadir Lengkap</span>
                <?php elseif ($sudah_masuk): ?>
                    <span class="badge badge-warning">🟡 Sudah Masuk</span>
                <?php else: ?>
                    <span class="badge badge-secondary">— Belum Absen</span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if ($sudah_izin || $sudah_sakit): ?>
                <div style="text-align:center;padding:24px 0;">
                    <div style="font-size:56px;margin-bottom:12px;"><?= $sudah_izin ? '📋' : '🏥' ?></div>
                    <div style="font-size:1.25rem;font-weight:700;margin-bottom:6px;">
                        Anda tercatat <span style="color:<?= $sudah_izin ? 'var(--primary)' : 'var(--warning)' ?>"><?= $sudah_izin ? 'Izin' : 'Sakit' ?></span> hari ini
                    </div>
                    <?php if (!empty($absensi_hari_ini['keterangan'])): ?>
                    <div style="color:var(--gray-600);margin-bottom:12px;">
                        Keterangan: <em>"<?= htmlspecialchars($absensi_hari_ini['keterangan']) ?>"</em>
                    </div>
                    <?php endif; ?>
                </div>

                <?php elseif ($sudah_tak): ?>
                <div style="text-align:center;padding:24px 0;">
                    <div style="font-size:56px;margin-bottom:12px;">❓</div>
                    <div style="font-size:1.25rem;font-weight:700;color:var(--gray-600);margin-bottom:6px;">
                        Tidak Ada Keterangan
                    </div>
                    <div style="color:var(--gray-500);font-size:0.875rem;">
                        Tidak ada catatan kehadiran. Hubungi admin jika perlu perubahan status.
                    </div>
                </div>

                <?php else: ?>
                <!-- Absen Masuk & Pulang -->
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                    <!-- Masuk -->
                    <div style="background:<?= $sudah_masuk ? '#d1fae5' : '#f8fafc' ?>;border:2px solid <?= $sudah_masuk ? 'var(--success)' : 'var(--gray-200)' ?>;border-radius:14px;padding:20px;text-align:center;">
                        <div style="font-size:2.5rem;margin-bottom:8px;"><?= $sudah_masuk ? '✅' : '🟢' ?></div>
                        <div style="font-weight:700;font-size:0.9375rem;margin-bottom:6px;">Absen Masuk</div>
                        <?php if ($sudah_masuk): ?>
                            <div style="font-size:1.5rem;font-weight:800;color:var(--success);"><?= formatTime($absensi_hari_ini['jam_masuk']) ?></div>
                            <span class="badge <?= $status_hari_ini==='terlambat' ? 'badge-warning' : 'badge-success' ?>" style="font-size:.7rem;margin-top:4px;">
                                <?= $status_hari_ini==='terlambat' ? 'Terlambat' : 'Tepat Waktu' ?>
                            </span>
                        <?php else: ?>
                            <div style="color:var(--gray-500);font-size:.85rem;margin-bottom:10px;">Belum absen masuk</div>
                            <a href="absensi.php" class="btn btn-sm" style="background:var(--success);color:white;font-size:.8rem;">
                                <i class="fas fa-sign-in-alt"></i> Absen Masuk
                            </a>
                        <?php endif; ?>
                    </div>
                    <!-- Pulang -->
                    <div style="background:<?= $sudah_pulang ? '#fee2e2' : '#f8fafc' ?>;border:2px solid <?= $sudah_pulang ? 'var(--danger)' : 'var(--gray-200)' ?>;border-radius:14px;padding:20px;text-align:center;">
                        <div style="font-size:2.5rem;margin-bottom:8px;"><?= $sudah_pulang ? '✅' : '🔴' ?></div>
                        <div style="font-weight:700;font-size:0.9375rem;margin-bottom:6px;">Absen Pulang</div>
                        <?php if ($sudah_pulang): ?>
                            <div style="font-size:1.5rem;font-weight:800;color:var(--danger);"><?= formatTime($absensi_hari_ini['jam_pulang']) ?></div>
                        <?php elseif ($sudah_masuk): ?>
                            <div style="color:var(--gray-500);font-size:.85rem;margin-bottom:10px;">Silakan absen pulang</div>
                            <a href="absensi.php" class="btn btn-sm" style="background:var(--danger);color:white;font-size:.8rem;">
                                <i class="fas fa-sign-out-alt"></i> Absen Pulang
                            </a>
                        <?php else: ?>
                            <div style="color:var(--gray-400);font-size:.85rem;">Absen masuk dulu</div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Statistik Bulan Ini -->
        <div class="stats-grid">
            <div class="stat-card green">
                <div class="stat-icon"><i class="fas fa-user-check"></i></div>
                <div class="stat-value"><?= $total_hadir ?></div>
                <div class="stat-label">Hadir Bulan Ini</div>
            </div>
            <div class="stat-card blue">
                <div class="stat-icon"><i class="fas fa-check-double"></i></div>
                <div class="stat-value"><?= $total_lengkap ?></div>
                <div class="stat-label">Absensi Lengkap</div>
            </div>
            <div class="stat-card" style="background:white;border:1px solid var(--gray-200);">
                <div class="stat-icon" style="background:var(--primary-light);color:var(--primary);"><i class="fas fa-file-alt"></i></div>
                <div class="stat-value"><?= $total_izin ?></div>
                <div class="stat-label">Izin Bulan Ini</div>
            </div>
            <div class="stat-card red">
                <div class="stat-icon"><i class="fas fa-briefcase-medical"></i></div>
                <div class="stat-value"><?= $total_sakit ?></div>
                <div class="stat-label">Sakit Bulan Ini</div>
            </div>
            <?php if ($total_tak > 0): ?>
            <div class="stat-card" style="background:white;border:2px solid var(--gray-300);">
                <div class="stat-icon" style="background:#f1f5f9;color:#64748b;"><i class="fas fa-question-circle"></i></div>
                <div class="stat-value" style="color:#64748b;"><?= $total_tak ?></div>
                <div class="stat-label">Tidak Ada Ket.</div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Riwayat Absensi Terbaru -->
        <div class="card">
            <div class="card-header">
                <div class="card-title"><i class="fas fa-history"></i> Riwayat Absensi Terbaru</div>
                <a href="riwayat.php" class="btn btn-outline btn-sm">Lihat Semua</a>
            </div>
            <div class="card-body" style="padding:0;">
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Jam Masuk</th>
                                <th>Jam Pulang</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($riwayat->num_rows > 0):
                            $statusMap = [
                                'hadir'               => ['badge-success',   '✅ Hadir'],
                                'terlambat'           => ['badge-warning',   '⚠️ Terlambat'],
                                'tidak_ada_keterangan'=> ['badge-secondary', '❓ Tidak Ada Ket.'],
                                'izin'                => ['badge-primary',   '📋 Izin'],
                                'sakit'               => ['badge-danger',    '🏥 Sakit'],
                            ];
                            while ($row = $riwayat->fetch_assoc()):
                            [$cls,$lbl] = $statusMap[$row['status']] ?? ['badge-secondary','—'];
                        ?>
                            <tr>
                                <td><strong><?= formatDate($row['tanggal']) ?></strong></td>
                                <td><span class="badge <?= $cls ?>" style="font-size:.7rem;"><?= $lbl ?></span></td>
                                <td>
                                    <?php if ($row['jam_masuk']): ?>
                                        <span style="color:var(--success);font-weight:600;">
                                            <i class="fas fa-sign-in-alt"></i> <?= formatTime($row['jam_masuk']) ?>
                                        </span>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['jam_pulang']): ?>
                                        <span style="color:var(--danger);font-weight:600;">
                                            <i class="fas fa-sign-out-alt"></i> <?= formatTime($row['jam_pulang']) ?>
                                        </span>
                                    <?php else: ?><span class="text-muted">—</span><?php endif; ?>
                                </td>
                                <td style="font-size:0.8125rem;color:var(--gray-600);">
                                    <?= htmlspecialchars($row['keterangan'] ?: '—') ?>
                                </td>
                            </tr>
                        <?php endwhile; else: ?>
                            <tr><td colspan="5" class="table-empty">
                                <div class="empty-icon">📅</div>
                                Belum ada riwayat absensi
                            </td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</div>

<script src="../js/mobile.js"></script>
</body>
</html>
