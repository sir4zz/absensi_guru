-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Apr 2026 pada 16.46
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `absensi_guru`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `id` int(11) NOT NULL,
  `guru_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `status` enum('hadir','terlambat','tidak_ada_keterangan','izin','sakit') NOT NULL DEFAULT 'tidak_ada_keterangan',
  `jam_masuk` time DEFAULT NULL,
  `jam_pulang` time DEFAULT NULL,
  `foto_masuk` varchar(255) DEFAULT NULL,
  `foto_pulang` varchar(255) DEFAULT NULL,
  `lat_masuk` decimal(10,7) DEFAULT NULL,
  `lng_masuk` decimal(10,7) DEFAULT NULL,
  `lat_pulang` decimal(10,7) DEFAULT NULL,
  `lng_pulang` decimal(10,7) DEFAULT NULL,
  `bukti_file` varchar(255) DEFAULT NULL COMMENT 'Wajib untuk izin/sakit, diupload admin',
  `keterangan` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `absensi`
--

INSERT INTO `absensi` (`id`, `guru_id`, `tanggal`, `status`, `jam_masuk`, `jam_pulang`, `foto_masuk`, `foto_pulang`, `lat_masuk`, `lng_masuk`, `lat_pulang`, `lng_pulang`, `bukti_file`, `keterangan`, `created_at`, `updated_at`) VALUES
(4, 14, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(5, 6, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(6, 17, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(7, 9, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(8, 15, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(9, 5, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(10, 11, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(11, 4, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(12, 12, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(13, 7, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(14, 13, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(15, 10, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(16, 16, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33'),
(17, 8, '2026-04-10', 'tidak_ada_keterangan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-04-10 14:45:33', '2026-04-10 14:45:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `nama`, `created_at`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', '2026-04-10 14:08:58');

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `sk` varchar(50) DEFAULT NULL,
  `spmt` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id`, `nama`, `nip`, `sk`, `spmt`, `password`, `created_at`) VALUES
(4, 'AGUS ABDUL GOFUR, S.Pd', '199108062025211119', '620 Tahun 2025', '800.1.13.2/20810-Dindikbud/2025', '$2y$10$2zN7OdZfBpaB3zrD9PwwTeqVwHnTMpiT/EWGgmu2MEnQJmgaTqn2K', '2026-04-10 14:44:56'),
(5, 'AHMAD FAOZI, S.Pd', '198911212025211113', '620 Tahun 2025', '800.1.13.2/20811-Dindikbud/2025', '$2y$10$gmkS5qoMFepseWjJPwgp4.cg0Is7v8apFO3YW8tCv9XF7wJj8KGGe', '2026-04-10 14:44:56'),
(6, 'ALI ROHMAN, S.Ag', '197102062025211035', '620 Tahun 2025', '800.1.13.2/20812-Dindikbud/2025', '$2y$10$msMHNE1t580mB.qgi09f2.r2qW0XehVRqoOdl7HUjcdB6ZfDPqg6y', '2026-04-10 14:44:56'),
(7, 'AMELIA PRATIWI, S.Pd', '199305282025212173', '620 Tahun 2025', '800.1.13.2/20807-Dindikbud/2025', '$2y$10$1lD/hApkoEHM9nXfuflXKeOc9WDqzT/pFFQpOT1CRMCKJ12a7hxVm', '2026-04-10 14:44:56'),
(8, 'ARY CATUR PRIYANTO', '200101152025211041', '620 Tahun 2025', '800.1.13.2/20813-Dindikbud/2025', '$2y$10$F.FDyfVDrF/62uteuMekkeiQ1LYRrMUGAIOumdxXN4c8/AoYE.Iv.', '2026-04-10 14:44:56'),
(9, 'BUNAJAT TOHIR, S.Pd', '198709272025211083', '620 Tahun 2025', '800.1.13.2/20668-Dindikbud/2025', '$2y$10$gq/.XzHbmns5csnJpvnsFeVvorbF7Hkb3IHOcpuca4feE0ZVu63PW', '2026-04-10 14:44:56'),
(10, 'NENEG KIKI, S.Pd', '199510082025212163', '620 Tahun 2025', '800.1.13.2/20808-Dindikbud/2025', '$2y$10$ZuOa33tJ0I053IqAFUmT/OZ.7LVUPFVB7rfwL2wyMgSmbJ2GMTdgO', '2026-04-10 14:44:57'),
(11, 'NINING NURHAYATI, S.Pd', '199006122025212220', '620 Tahun 2025', '800.1.13.2/20806-Dindikbud/2025', '$2y$10$0xD647sFetOgblItrCClDeOItrh7zss6e4uv7ICUOEwhGC7UYIZDS', '2026-04-10 14:44:57'),
(12, 'SEPTIAN HERNAWAN, SE', '199109152025211099', '620 Tahun 2025', '800.1.13.2/20667-Dindikbud/2025', '$2y$10$Y9umAEyXbHYMwcLv5.lcCuzg3Ozxa9no0MTOk.XV2Ga4chnutUoXa', '2026-04-10 14:44:57'),
(13, 'SITI WIDIASTUTI PUJIASWATI, S.Pd', '199505182025212080', '620 Tahun 2025', '800.1.13.2/20666-Dindikbud/2025', '$2y$10$Vjb7EkYtL6qlEpEB5XwCveGNooVEvw66Mfv53O3D/vbU.R36WbEbG', '2026-04-10 14:44:57'),
(14, 'ENDANG', '196909142025211027', '620 Tahun 2025', '800.1.13.2/19767-Dindikbud/2025', '$2y$10$DqV3bCJ4hd2D1gUR8UxXiu0/aGXCCyymuQjRYzQtYHAKtVcHHludC', '2026-04-10 14:44:57'),
(15, 'HARDINATA', '198807222025211075', '620 Tahun 2025', '800.1.13.2/19768-Dindikbud/2025', '$2y$10$delJwTULlMUJBrw6.jtJeu5WITA1IndvyyrvIUPMBteO9N/8UBay6', '2026-04-10 14:44:58'),
(16, 'NURHOLIS MAJID, MM', '199906102025211049', '620 Tahun 2025', '800.1.13.2/19765-Dindikbud/2025', '$2y$10$pwl/mlvvxJ28h0JmsNWVcOm6sZnxR7o8LX1li7NIwrF2fqjel6HjO', '2026-04-10 14:44:58'),
(17, 'SAYATI', '198306282025212053', '620 Tahun 2025', '800.1.13.2/19766-Dindikbud/2025', '$2y$10$KcSwsYOc/wfPmoM8P0PjDul1bB2kvgMKRQuZLQtnrTZKIuvbyogkW', '2026-04-10 14:44:58');

-- --------------------------------------------------------

--
-- Struktur dari tabel `izin_absen`
--

CREATE TABLE `izin_absen` (
  `id` int(11) NOT NULL,
  `guru_id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `dibuat_oleh` int(11) NOT NULL COMMENT 'admin.id',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_absensi` (`guru_id`,`tanggal`);

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nip` (`nip`);

--
-- Indeks untuk tabel `izin_absen`
--
ALTER TABLE `izin_absen`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_izin` (`guru_id`,`tanggal`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `guru`
--
ALTER TABLE `guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT untuk tabel `izin_absen`
--
ALTER TABLE `izin_absen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `absensi_ibfk_1` FOREIGN KEY (`guru_id`) REFERENCES `guru` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `izin_absen`
--
ALTER TABLE `izin_absen`
  ADD CONSTRAINT `izin_absen_ibfk_1` FOREIGN KEY (`guru_id`) REFERENCES `guru` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
